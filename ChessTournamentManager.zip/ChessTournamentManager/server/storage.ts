import {
  users, 
  type User, 
  type InsertUser,
  tournaments,
  type Tournament,
  type InsertTournament,
  groups,
  type Group,
  type InsertGroup,
  playerGroups,
  type PlayerGroup,
  type InsertPlayerGroup,
  matches,
  type Match,
  type InsertMatch,
  activityLogs,
  type ActivityLog,
  type InsertActivityLog,
  type MatchWithDetails
} from "@shared/schema";

export interface IStorage {
  // User management
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByCredentialCode(code: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getPlayers(): Promise<User[]>;
  
  // Tournament management
  createTournament(tournament: InsertTournament): Promise<Tournament>;
  getTournaments(): Promise<Tournament[]>;
  getTournament(id: number): Promise<Tournament | undefined>;
  getActiveTournament(): Promise<Tournament | undefined>;
  setActiveTournament(id: number): Promise<Tournament | undefined>;
  
  // Group management
  createGroup(group: InsertGroup): Promise<Group>;
  getGroups(tournamentId: number): Promise<Group[]>;
  getGroup(id: number): Promise<Group | undefined>;
  assignPlayerToGroup(assignment: InsertPlayerGroup): Promise<PlayerGroup>;
  getGroupPlayers(groupId: number): Promise<User[]>;
  getPlayerGroup(playerId: number, tournamentId: number): Promise<Group | undefined>;
  
  // Match management
  createMatch(match: InsertMatch): Promise<Match>;
  getMatches(tournamentId: number, groupId?: number): Promise<MatchWithDetails[]>;
  getMatch(id: number): Promise<Match | undefined>;
  getMatchWithDetails(id: number): Promise<MatchWithDetails | undefined>;
  updateMatchResult(id: number, player1Score: string, player2Score: string): Promise<Match | undefined>;
  getPlayerMatches(playerId: number, tournamentId: number): Promise<MatchWithDetails[]>;
  
  // Activity log
  createActivityLog(log: InsertActivityLog): Promise<ActivityLog>;
  getRecentActivity(tournamentId: number, limit?: number): Promise<ActivityLog[]>;
  
  // Tournament statistics
  getPlayerStatistics(playerId: number, tournamentId: number): Promise<PlayerStatistics>;
  getGroupStandings(groupId: number): Promise<PlayerStanding[]>;
  getTournamentStandings(tournamentId: number): Promise<PlayerStanding[]>;
}

// Player statistics interface
export interface PlayerStatistics {
  played: number;
  wins: number;
  draws: number;
  losses: number;
  points: number;
}

// Player standing interface for group/tournament standings
export interface PlayerStanding {
  playerId: number;
  playerName: string;
  credentialCode: string;
  played: number;
  wins: number;
  draws: number;
  losses: number;
  points: number;
  rank?: number;
}

export class MemStorage implements IStorage {
  private usersStore: Map<number, User>;
  private tournamentsStore: Map<number, Tournament>;
  private groupsStore: Map<number, Group>;
  private playerGroupsStore: Map<number, PlayerGroup>;
  private matchesStore: Map<number, Match>;
  private activityLogsStore: Map<number, ActivityLog>;
  
  private currentUserId: number;
  private currentTournamentId: number;
  private currentGroupId: number;
  private currentPlayerGroupId: number;
  private currentMatchId: number;
  private currentActivityLogId: number;

  constructor() {
    this.usersStore = new Map();
    this.tournamentsStore = new Map();
    this.groupsStore = new Map();
    this.playerGroupsStore = new Map();
    this.matchesStore = new Map();
    this.activityLogsStore = new Map();
    
    this.currentUserId = 1;
    this.currentTournamentId = 1;
    this.currentGroupId = 1;
    this.currentPlayerGroupId = 1;
    this.currentMatchId = 1;
    this.currentActivityLogId = 1;
  }

  // User management
  async getUser(id: number): Promise<User | undefined> {
    return this.usersStore.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.usersStore.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase(),
    );
  }

  async getUserByCredentialCode(code: string): Promise<User | undefined> {
    return Array.from(this.usersStore.values()).find(
      (user) => user.credentialCode === code,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      id,
      username: insertUser.username,
      password: insertUser.password,
      fullName: insertUser.fullName,
      isAdmin: insertUser.isAdmin ?? false,
      credentialCode: insertUser.credentialCode
    };
    this.usersStore.set(id, user);
    return user;
  }

  async getPlayers(): Promise<User[]> {
    return Array.from(this.usersStore.values()).filter(
      (user) => !user.isAdmin
    );
  }

  // Tournament management
  async createTournament(insertTournament: InsertTournament): Promise<Tournament> {
    const id = this.currentTournamentId++;
    
    // Assicuriamoci che tutti i campi siano nel formato corretto
    const tournament: Tournament = { 
      id,
      name: insertTournament.name,
      description: insertTournament.description ?? null,
      location: insertTournament.location ?? null,
      startDate: insertTournament.startDate,
      endDate: insertTournament.endDate ?? null,
      active: insertTournament.active ?? false,
      tournamentType: insertTournament.tournamentType ?? "swiss",
      numberOfRounds: insertTournament.numberOfRounds ?? null,
      numberOfBoards: insertTournament.numberOfBoards ?? null,
      createdBy: insertTournament.createdBy
    };
    
    this.tournamentsStore.set(id, tournament);
    return tournament;
  }

  async getTournaments(): Promise<Tournament[]> {
    return Array.from(this.tournamentsStore.values());
  }

  async getTournament(id: number): Promise<Tournament | undefined> {
    return this.tournamentsStore.get(id);
  }

  async getActiveTournament(): Promise<Tournament | undefined> {
    return Array.from(this.tournamentsStore.values()).find(
      (tournament) => tournament.active
    );
  }

  async setActiveTournament(id: number): Promise<Tournament | undefined> {
    // Set all tournaments inactive
    for (const tournament of this.tournamentsStore.values()) {
      tournament.active = tournament.id === id;
      this.tournamentsStore.set(tournament.id, tournament);
    }
    
    return this.tournamentsStore.get(id);
  }

  // Group management
  async createGroup(insertGroup: InsertGroup): Promise<Group> {
    const id = this.currentGroupId++;
    const group: Group = { ...insertGroup, id };
    this.groupsStore.set(id, group);
    return group;
  }

  async getGroups(tournamentId: number): Promise<Group[]> {
    return Array.from(this.groupsStore.values()).filter(
      (group) => group.tournamentId === tournamentId
    );
  }

  async getGroup(id: number): Promise<Group | undefined> {
    return this.groupsStore.get(id);
  }

  async assignPlayerToGroup(insertPlayerGroup: InsertPlayerGroup): Promise<PlayerGroup> {
    const id = this.currentPlayerGroupId++;
    const playerGroup: PlayerGroup = { ...insertPlayerGroup, id };
    this.playerGroupsStore.set(id, playerGroup);
    return playerGroup;
  }

  async getGroupPlayers(groupId: number): Promise<User[]> {
    const playerGroupAssignments = Array.from(this.playerGroupsStore.values()).filter(
      (playerGroup) => playerGroup.groupId === groupId
    );
    
    const players = [];
    for (const assignment of playerGroupAssignments) {
      const player = await this.getUser(assignment.playerId);
      if (player) players.push(player);
    }
    
    return players;
  }

  async getPlayerGroup(playerId: number, tournamentId: number): Promise<Group | undefined> {
    // Find groups for this tournament
    const tournamentGroups = Array.from(this.groupsStore.values()).filter(
      (group) => group.tournamentId === tournamentId
    );
    
    // Find player-group assignments for this player
    for (const group of tournamentGroups) {
      const playerGroupAssignment = Array.from(this.playerGroupsStore.values()).find(
        (playerGroup) => playerGroup.groupId === group.id && playerGroup.playerId === playerId
      );
      
      if (playerGroupAssignment) {
        return group;
      }
    }
    
    return undefined;
  }

  // Match management
  async createMatch(insertMatch: InsertMatch): Promise<Match> {
    const id = this.currentMatchId++;
    const match: Match = { ...insertMatch, id };
    this.matchesStore.set(id, match);
    return match;
  }

  async getMatches(tournamentId: number, groupId?: number): Promise<MatchWithDetails[]> {
    const tournamentMatches = Array.from(this.matchesStore.values()).filter(
      (match) => match.tournamentId === tournamentId && (groupId === undefined || match.groupId === groupId)
    );
    
    // Enhance matches with player and group details
    const enhancedMatches = [];
    for (const match of tournamentMatches) {
      const player1 = await this.getUser(match.player1Id);
      const player2 = await this.getUser(match.player2Id);
      const group = match.groupId ? await this.getGroup(match.groupId) : undefined;
      
      const matchWithDetails: MatchWithDetails = {
        ...match,
        player1: player1 ? { id: player1.id, fullName: player1.fullName, credentialCode: player1.credentialCode } : undefined,
        player2: player2 ? { id: player2.id, fullName: player2.fullName, credentialCode: player2.credentialCode } : undefined,
        group: group ? { id: group.id, name: group.name } : undefined
      };
      
      enhancedMatches.push(matchWithDetails);
    }
    
    return enhancedMatches;
  }

  async getMatch(id: number): Promise<Match | undefined> {
    return this.matchesStore.get(id);
  }

  async getMatchWithDetails(id: number): Promise<MatchWithDetails | undefined> {
    const match = this.matchesStore.get(id);
    if (!match) return undefined;
    
    const player1 = await this.getUser(match.player1Id);
    const player2 = await this.getUser(match.player2Id);
    const group = match.groupId ? await this.getGroup(match.groupId) : undefined;
    
    return {
      ...match,
      player1: player1 ? { id: player1.id, fullName: player1.fullName, credentialCode: player1.credentialCode } : undefined,
      player2: player2 ? { id: player2.id, fullName: player2.fullName, credentialCode: player2.credentialCode } : undefined,
      group: group ? { id: group.id, name: group.name } : undefined
    };
  }

  async updateMatchResult(id: number, player1Score: string, player2Score: string): Promise<Match | undefined> {
    const match = this.matchesStore.get(id);
    if (!match) return undefined;
    
    const updatedMatch: Match = {
      ...match,
      player1Score,
      player2Score,
      completed: true
    };
    
    this.matchesStore.set(id, updatedMatch);
    return updatedMatch;
  }

  async getPlayerMatches(playerId: number, tournamentId: number): Promise<MatchWithDetails[]> {
    const playerMatches = Array.from(this.matchesStore.values()).filter(
      (match) => match.tournamentId === tournamentId && 
                (match.player1Id === playerId || match.player2Id === playerId)
    );
    
    // Enhance matches with player and group details
    const enhancedMatches = [];
    for (const match of playerMatches) {
      const player1 = await this.getUser(match.player1Id);
      const player2 = await this.getUser(match.player2Id);
      const group = match.groupId ? await this.getGroup(match.groupId) : undefined;
      
      const matchWithDetails: MatchWithDetails = {
        ...match,
        player1: player1 ? { id: player1.id, fullName: player1.fullName, credentialCode: player1.credentialCode } : undefined,
        player2: player2 ? { id: player2.id, fullName: player2.fullName, credentialCode: player2.credentialCode } : undefined,
        group: group ? { id: group.id, name: group.name } : undefined
      };
      
      enhancedMatches.push(matchWithDetails);
    }
    
    return enhancedMatches;
  }

  // Activity log
  async createActivityLog(insertActivityLog: InsertActivityLog): Promise<ActivityLog> {
    const id = this.currentActivityLogId++;
    const activityLog: ActivityLog = { 
      ...insertActivityLog, 
      id,
      timestamp: new Date() 
    };
    this.activityLogsStore.set(id, activityLog);
    return activityLog;
  }

  async getRecentActivity(tournamentId: number, limit: number = 10): Promise<ActivityLog[]> {
    return Array.from(this.activityLogsStore.values())
      .filter((log) => log.tournamentId === tournamentId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }

  // Tournament statistics
  async getPlayerStatistics(playerId: number, tournamentId: number): Promise<PlayerStatistics> {
    const playerMatches = Array.from(this.matchesStore.values()).filter(
      (match) => match.tournamentId === tournamentId && 
                (match.player1Id === playerId || match.player2Id === playerId) &&
                match.completed
    );
    
    let wins = 0;
    let draws = 0;
    let losses = 0;
    
    for (const match of playerMatches) {
      if (match.player1Id === playerId) {
        if (match.player1Score === "1" && match.player2Score === "0") {
          wins++;
        } else if (match.player1Score === "0.5" && match.player2Score === "0.5") {
          draws++;
        } else if (match.player1Score === "0" && match.player2Score === "1") {
          losses++;
        }
      } else {
        if (match.player2Score === "1" && match.player1Score === "0") {
          wins++;
        } else if (match.player2Score === "0.5" && match.player1Score === "0.5") {
          draws++;
        } else if (match.player2Score === "0" && match.player1Score === "1") {
          losses++;
        }
      }
    }
    
    const played = wins + draws + losses;
    const points = wins + draws * 0.5;
    
    return {
      played,
      wins,
      draws,
      losses,
      points
    };
  }

  async getGroupStandings(groupId: number): Promise<PlayerStanding[]> {
    const group = await this.getGroup(groupId);
    if (!group) return [];
    
    const players = await this.getGroupPlayers(groupId);
    const standings: PlayerStanding[] = [];
    
    for (const player of players) {
      const stats = await this.getPlayerStatistics(player.id, group.tournamentId);
      
      standings.push({
        playerId: player.id,
        playerName: player.fullName,
        credentialCode: player.credentialCode,
        ...stats
      });
    }
    
    // Sort by points (descending)
    standings.sort((a, b) => b.points - a.points);
    
    // Add ranking
    standings.forEach((standing, index) => {
      standing.rank = index + 1;
    });
    
    return standings;
  }

  async getTournamentStandings(tournamentId: number): Promise<PlayerStanding[]> {
    const groups = await this.getGroups(tournamentId);
    let allStandings: PlayerStanding[] = [];
    
    for (const group of groups) {
      const groupStandings = await this.getGroupStandings(group.id);
      allStandings = [...allStandings, ...groupStandings];
    }
    
    // Sort by points (descending)
    allStandings.sort((a, b) => b.points - a.points);
    
    // Add ranking
    allStandings.forEach((standing, index) => {
      standing.rank = index + 1;
    });
    
    return allStandings;
  }
}

import { db } from "./db";
import { eq, and, desc, asc, isNull, or } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export class DatabaseStorage implements IStorage {
  sessionStore: session.SessionStore;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
  }

  // User management
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByCredentialCode(code: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.credentialCode, code));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getPlayers(): Promise<User[]> {
    return db.select().from(users).where(eq(users.isAdmin, false));
  }

  // Tournament management
  async createTournament(insertTournament: InsertTournament): Promise<Tournament> {
    // Normalizza i campi per evitare problemi con i valori undefined
    
    // Converti le stringhe di data in oggetti Date se necessario
    let startDate: Date;
    let endDate: Date | null = null;
    
    if (typeof insertTournament.startDate === 'string') {
      startDate = new Date(insertTournament.startDate);
    } else {
      startDate = insertTournament.startDate;
    }
    
    if (insertTournament.endDate) {
      if (typeof insertTournament.endDate === 'string') {
        endDate = new Date(insertTournament.endDate);
      } else {
        endDate = insertTournament.endDate;
      }
    }
    
    const normalizedData = {
      name: insertTournament.name,
      description: insertTournament.description ?? null,
      location: insertTournament.location ?? null,
      startDate: startDate,
      endDate: endDate,
      active: insertTournament.active ?? false,
      tournamentType: insertTournament.tournamentType ?? "swiss",
      numberOfRounds: insertTournament.numberOfRounds ?? null,
      numberOfBoards: insertTournament.numberOfBoards ?? null,
      createdBy: insertTournament.createdBy
    };
    
    console.log('Database insert tournament:', normalizedData);
    
    const [tournament] = await db.insert(tournaments).values(normalizedData).returning();
    return tournament;
  }

  async getTournaments(): Promise<Tournament[]> {
    return db.select().from(tournaments);
  }

  async getTournament(id: number): Promise<Tournament | undefined> {
    const [tournament] = await db.select().from(tournaments).where(eq(tournaments.id, id));
    return tournament;
  }

  async getActiveTournament(): Promise<Tournament | undefined> {
    const [tournament] = await db.select().from(tournaments).where(eq(tournaments.active, true));
    return tournament;
  }

  async setActiveTournament(id: number): Promise<Tournament | undefined> {
    // Set all to inactive
    await db.update(tournaments).set({ active: false });
    
    // Set target to active
    await db.update(tournaments)
      .set({ active: true })
      .where(eq(tournaments.id, id));
    
    return this.getTournament(id);
  }

  // Group management
  async createGroup(insertGroup: InsertGroup): Promise<Group> {
    const [group] = await db.insert(groups).values(insertGroup).returning();
    return group;
  }

  async getGroups(tournamentId: number): Promise<Group[]> {
    return db.select().from(groups).where(eq(groups.tournamentId, tournamentId));
  }

  async getGroup(id: number): Promise<Group | undefined> {
    const [group] = await db.select().from(groups).where(eq(groups.id, id));
    return group;
  }

  async assignPlayerToGroup(assignment: InsertPlayerGroup): Promise<PlayerGroup> {
    const [playerGroup] = await db.insert(playerGroups).values(assignment).returning();
    return playerGroup;
  }

  async getGroupPlayers(groupId: number): Promise<User[]> {
    const playerGroupAssignments = await db.select()
      .from(playerGroups)
      .where(eq(playerGroups.groupId, groupId));
    
    if (!playerGroupAssignments.length) return [];
    
    const playerIds = playerGroupAssignments.map(pg => pg.playerId);
    
    return db.select()
      .from(users)
      .where(
        playerIds.map(id => eq(users.id, id)).reduce((acc, condition) => 
          acc ? or(acc, condition) : condition, undefined)
      );
  }

  async getPlayerGroup(playerId: number, tournamentId: number): Promise<Group | undefined> {
    const [playerGroupAssignment] = await db.select()
      .from(playerGroups)
      .innerJoin(groups, eq(playerGroups.groupId, groups.id))
      .where(
        and(
          eq(playerGroups.playerId, playerId),
          eq(groups.tournamentId, tournamentId)
        )
      );
    
    if (!playerGroupAssignment) return undefined;
    
    return playerGroupAssignment.groups;
  }

  // Match management
  async createMatch(insertMatch: InsertMatch): Promise<Match> {
    const [match] = await db.insert(matches).values(insertMatch).returning();
    return match;
  }

  async getMatches(tournamentId: number, groupId?: number): Promise<MatchWithDetails[]> {
    const matchesData = await db.select().from(matches).where(
      groupId 
        ? and(eq(matches.tournamentId, tournamentId), eq(matches.groupId, groupId))
        : eq(matches.tournamentId, tournamentId)
    );

    const enhancedMatches: MatchWithDetails[] = [];
    
    for (const match of matchesData) {
      const player1 = await this.getUser(match.player1Id);
      const player2 = await this.getUser(match.player2Id);
      const group = match.groupId ? await this.getGroup(match.groupId) : undefined;
      
      enhancedMatches.push({
        ...match,
        player1: player1 ? { 
          id: player1.id, 
          fullName: player1.fullName, 
          credentialCode: player1.credentialCode 
        } : undefined,
        player2: player2 ? { 
          id: player2.id, 
          fullName: player2.fullName, 
          credentialCode: player2.credentialCode 
        } : undefined,
        group: group ? { 
          id: group.id, 
          name: group.name 
        } : undefined
      });
    }
    
    return enhancedMatches;
  }

  async getMatch(id: number): Promise<Match | undefined> {
    const [match] = await db.select().from(matches).where(eq(matches.id, id));
    return match;
  }

  async getMatchWithDetails(id: number): Promise<MatchWithDetails | undefined> {
    const [match] = await db.select().from(matches).where(eq(matches.id, id));
    if (!match) return undefined;

    const player1 = await this.getUser(match.player1Id);
    const player2 = await this.getUser(match.player2Id);
    const group = match.groupId ? await this.getGroup(match.groupId) : undefined;
    
    return {
      ...match,
      player1: player1 ? { 
        id: player1.id, 
        fullName: player1.fullName, 
        credentialCode: player1.credentialCode 
      } : undefined,
      player2: player2 ? { 
        id: player2.id, 
        fullName: player2.fullName, 
        credentialCode: player2.credentialCode 
      } : undefined,
      group: group ? { 
        id: group.id, 
        name: group.name 
      } : undefined
    };
  }

  async updateMatchResult(id: number, player1Score: string, player2Score: string): Promise<Match | undefined> {
    const [updatedMatch] = await db.update(matches)
      .set({
        player1Score,
        player2Score,
        completed: true
      })
      .where(eq(matches.id, id))
      .returning();
    
    return updatedMatch;
  }

  async getPlayerMatches(playerId: number, tournamentId: number): Promise<MatchWithDetails[]> {
    const playerMatches = await db.select()
      .from(matches)
      .where(
        and(
          eq(matches.tournamentId, tournamentId),
          or(eq(matches.player1Id, playerId), eq(matches.player2Id, playerId))
        )
      );

    const enhancedMatches: MatchWithDetails[] = [];
    
    for (const match of playerMatches) {
      const player1 = await this.getUser(match.player1Id);
      const player2 = await this.getUser(match.player2Id);
      const group = match.groupId ? await this.getGroup(match.groupId) : undefined;
      
      enhancedMatches.push({
        ...match,
        player1: player1 ? { 
          id: player1.id, 
          fullName: player1.fullName, 
          credentialCode: player1.credentialCode 
        } : undefined,
        player2: player2 ? { 
          id: player2.id, 
          fullName: player2.fullName, 
          credentialCode: player2.credentialCode 
        } : undefined,
        group: group ? { 
          id: group.id, 
          name: group.name 
        } : undefined
      });
    }
    
    return enhancedMatches;
  }

  // Activity log
  async createActivityLog(log: InsertActivityLog): Promise<ActivityLog> {
    const [activityLog] = await db.insert(activityLogs)
      .values({
        ...log,
        timestamp: new Date()
      })
      .returning();
    
    return activityLog;
  }

  async getRecentActivity(tournamentId: number, limit: number = 10): Promise<ActivityLog[]> {
    return db.select()
      .from(activityLogs)
      .where(eq(activityLogs.tournamentId, tournamentId))
      .orderBy(desc(activityLogs.timestamp))
      .limit(limit);
  }

  // Tournament statistics
  async getPlayerStatistics(playerId: number, tournamentId: number): Promise<PlayerStatistics> {
    const playerMatches = await db.select()
      .from(matches)
      .where(
        and(
          eq(matches.tournamentId, tournamentId),
          or(eq(matches.player1Id, playerId), eq(matches.player2Id, playerId)),
          eq(matches.completed, true)
        )
      );

    let wins = 0;
    let draws = 0;
    let losses = 0;
    
    for (const match of playerMatches) {
      if (match.player1Id === playerId) {
        if (match.player1Score === "1" && match.player2Score === "0") {
          wins++;
        } else if (match.player1Score === "0.5" && match.player2Score === "0.5") {
          draws++;
        } else if (match.player1Score === "0" && match.player2Score === "1") {
          losses++;
        }
      } else {
        if (match.player2Score === "1" && match.player1Score === "0") {
          wins++;
        } else if (match.player2Score === "0.5" && match.player1Score === "0.5") {
          draws++;
        } else if (match.player2Score === "0" && match.player1Score === "1") {
          losses++;
        }
      }
    }
    
    const played = wins + draws + losses;
    const points = wins + draws * 0.5;
    
    return {
      played,
      wins,
      draws,
      losses,
      points
    };
  }

  async getGroupStandings(groupId: number): Promise<PlayerStanding[]> {
    const group = await this.getGroup(groupId);
    if (!group) return [];
    
    const players = await this.getGroupPlayers(groupId);
    const standings: PlayerStanding[] = [];
    
    for (const player of players) {
      const stats = await this.getPlayerStatistics(player.id, group.tournamentId);
      
      standings.push({
        playerId: player.id,
        playerName: player.fullName,
        credentialCode: player.credentialCode,
        ...stats
      });
    }
    
    // Sort by points (descending)
    standings.sort((a, b) => b.points - a.points);
    
    // Add ranking
    standings.forEach((standing, index) => {
      standing.rank = index + 1;
    });
    
    return standings;
  }

  async getTournamentStandings(tournamentId: number): Promise<PlayerStanding[]> {
    const groups = await this.getGroups(tournamentId);
    let allStandings: PlayerStanding[] = [];
    
    for (const group of groups) {
      const groupStandings = await this.getGroupStandings(group.id);
      allStandings = [...allStandings, ...groupStandings];
    }
    
    // Sort by points (descending)
    allStandings.sort((a, b) => b.points - a.points);
    
    // Add ranking
    allStandings.forEach((standing, index) => {
      standing.rank = index + 1;
    });
    
    return allStandings;
  }
}

// Replace MemStorage with the new DatabaseStorage
export const storage = new DatabaseStorage();
