import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { setupAuth, hashPassword } from "./auth";
import { storage } from "./storage";
import {
  insertUserSchema,
  insertTournamentSchema,
  insertGroupSchema,
  insertPlayerGroupSchema,
  insertMatchSchema,
  insertActivityLogSchema,
  matchResultSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // API routes - All routes are prefixed with /api
  
  // User management
  app.get("/api/players", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const players = await storage.getPlayers();
      // Remove password from response
      const sanitizedPlayers = players.map(({ password, ...rest }) => rest);
      res.json(sanitizedPlayers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch players" });
    }
  });

  // Tournament management
  app.post("/api/tournaments", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      console.log('Tournament data received:', req.body);
      
      // Correggi i valori del torneo prima di validarli
      // Converti esplicitamente le stringhe di date in oggetti Date
      const startDate = new Date(req.body.startDate);
      const endDate = req.body.endDate ? new Date(req.body.endDate) : null;
      
      const normalizedTournamentData = {
        name: req.body.name,
        description: req.body.description ?? null,
        location: req.body.location ?? null,
        startDate: startDate,
        endDate: endDate,
        active: req.body.active ?? false,
        tournamentType: req.body.tournamentType ?? "swiss",
        numberOfRounds: req.body.numberOfRounds ?? null,
        numberOfBoards: req.body.numberOfBoards ?? null,
        createdBy: req.user.id
      };
      
      console.log('Normalized tournament data:', normalizedTournamentData);
      
      // Valida e crea il torneo
      const tournament = await storage.createTournament(normalizedTournamentData);
      
      console.log('Tournament created:', tournament);
      
      // Log activity
      await storage.createActivityLog({
        tournamentId: tournament.id,
        activity: `Tournament '${tournament.name}' created`,
        userId: req.user.id
      });
      
      res.status(201).json(tournament);
    } catch (error) {
      console.error('Error creating tournament:', error);
      res.status(400).json({ 
        message: "Invalid tournament data", 
        error: String(error),
        details: error instanceof Error ? error.stack : undefined
      });
    }
  });

  app.get("/api/tournaments", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const tournaments = await storage.getTournaments();
      res.json(tournaments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tournaments" });
    }
  });

  app.get("/api/tournaments/active", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const activeTournament = await storage.getActiveTournament();
      if (!activeTournament) {
        return res.status(404).json({ message: "No active tournament found" });
      }
      
      res.json(activeTournament);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch active tournament" });
    }
  });

  app.post("/api/tournaments/:id/activate", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const tournamentId = parseInt(req.params.id);
      const tournament = await storage.setActiveTournament(tournamentId);
      
      if (!tournament) {
        return res.status(404).json({ message: "Tournament not found" });
      }
      
      // Log activity
      await storage.createActivityLog({
        tournamentId: tournament.id,
        activity: `Tournament '${tournament.name}' set as active`,
        userId: req.user.id
      });
      
      res.json(tournament);
    } catch (error) {
      res.status(500).json({ message: "Failed to activate tournament" });
    }
  });

  // Group management
  app.post("/api/groups", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const groupData = insertGroupSchema.parse(req.body);
      const group = await storage.createGroup(groupData);
      
      // Log activity
      await storage.createActivityLog({
        tournamentId: group.tournamentId,
        activity: `Group '${group.name}' created`,
        userId: req.user.id
      });
      
      res.status(201).json(group);
    } catch (error) {
      res.status(400).json({ message: "Invalid group data" });
    }
  });

  app.get("/api/tournaments/:id/groups", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const tournamentId = parseInt(req.params.id);
      const groups = await storage.getGroups(tournamentId);
      res.json(groups);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch groups" });
    }
  });

  app.post("/api/groups/:id/players", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const groupId = parseInt(req.params.id);
      const { playerId } = req.body;
      
      if (!playerId) {
        return res.status(400).json({ message: "Player ID is required" });
      }
      
      const group = await storage.getGroup(groupId);
      if (!group) {
        return res.status(404).json({ message: "Group not found" });
      }
      
      const player = await storage.getUser(playerId);
      if (!player) {
        return res.status(404).json({ message: "Player not found" });
      }
      
      const playerGroupData = insertPlayerGroupSchema.parse({
        playerId,
        groupId
      });
      
      const playerGroup = await storage.assignPlayerToGroup(playerGroupData);
      
      // Log activity
      await storage.createActivityLog({
        tournamentId: group.tournamentId,
        activity: `Player '${player.fullName}' assigned to group '${group.name}'`,
        userId: req.user.id
      });
      
      res.status(201).json(playerGroup);
    } catch (error) {
      res.status(400).json({ message: "Failed to assign player to group" });
    }
  });

  app.get("/api/groups/:id/players", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const groupId = parseInt(req.params.id);
      const players = await storage.getGroupPlayers(groupId);
      
      // Remove password from response
      const sanitizedPlayers = players.map(({ password, ...rest }) => rest);
      
      res.json(sanitizedPlayers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch group players" });
    }
  });

  // Match management
  app.post("/api/matches", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const matchData = insertMatchSchema.parse(req.body);
      const match = await storage.createMatch(matchData);
      
      // Get player names for activity log
      const player1 = await storage.getUser(match.player1Id);
      const player2 = await storage.getUser(match.player2Id);
      
      // Log activity
      await storage.createActivityLog({
        tournamentId: match.tournamentId,
        activity: `Match created between ${player1?.fullName} and ${player2?.fullName}`,
        userId: req.user.id
      });
      
      res.status(201).json(match);
    } catch (error) {
      res.status(400).json({ message: "Invalid match data" });
    }
  });

  app.get("/api/tournaments/:id/matches", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const tournamentId = parseInt(req.params.id);
      const groupId = req.query.groupId ? parseInt(req.query.groupId as string) : undefined;
      
      const matches = await storage.getMatches(tournamentId, groupId);
      res.json(matches);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch matches" });
    }
  });

  app.get("/api/matches/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const matchId = parseInt(req.params.id);
      const match = await storage.getMatchWithDetails(matchId);
      
      if (!match) {
        return res.status(404).json({ message: "Match not found" });
      }
      
      res.json(match);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch match" });
    }
  });

  app.patch("/api/matches/:id/result", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const matchId = parseInt(req.params.id);
      const { player1Score, player2Score } = matchResultSchema.parse({
        ...req.body,
        matchId
      });
      
      const match = await storage.updateMatchResult(matchId, player1Score, player2Score);
      
      if (!match) {
        return res.status(404).json({ message: "Match not found" });
      }
      
      // Get player names for activity log
      const player1 = await storage.getUser(match.player1Id);
      const player2 = await storage.getUser(match.player2Id);
      
      let resultText = "";
      if (player1Score === "1" && player2Score === "0") {
        resultText = `${player1?.fullName} defeated ${player2?.fullName}`;
      } else if (player1Score === "0" && player2Score === "1") {
        resultText = `${player2?.fullName} defeated ${player1?.fullName}`;
      } else {
        resultText = `${player1?.fullName} drew with ${player2?.fullName}`;
      }
      
      // Log activity
      await storage.createActivityLog({
        tournamentId: match.tournamentId,
        activity: `Match result recorded: ${resultText}`,
        userId: req.user.id
      });
      
      res.json(match);
    } catch (error) {
      res.status(400).json({ message: "Invalid match result data" });
    }
  });

  app.get("/api/players/:id/matches", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const playerId = parseInt(req.params.id);
      const tournamentId = parseInt(req.query.tournamentId as string);
      
      if (!tournamentId) {
        return res.status(400).json({ message: "Tournament ID is required" });
      }
      
      const matches = await storage.getPlayerMatches(playerId, tournamentId);
      res.json(matches);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch player matches" });
    }
  });

  // Activity log
  app.get("/api/tournaments/:id/activity", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const tournamentId = parseInt(req.params.id);
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      
      const activities = await storage.getRecentActivity(tournamentId, limit);
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch activity logs" });
    }
  });

  // Tournament statistics
  app.get("/api/players/:id/statistics", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const playerId = parseInt(req.params.id);
      const tournamentId = parseInt(req.query.tournamentId as string);
      
      if (!tournamentId) {
        return res.status(400).json({ message: "Tournament ID is required" });
      }
      
      const statistics = await storage.getPlayerStatistics(playerId, tournamentId);
      res.json(statistics);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch player statistics" });
    }
  });

  app.get("/api/groups/:id/standings", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const groupId = parseInt(req.params.id);
      const standings = await storage.getGroupStandings(groupId);
      res.json(standings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch group standings" });
    }
  });

  app.get("/api/tournaments/:id/standings", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const tournamentId = parseInt(req.params.id);
      const standings = await storage.getTournamentStandings(tournamentId);
      res.json(standings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tournament standings" });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);
  return httpServer;
}
