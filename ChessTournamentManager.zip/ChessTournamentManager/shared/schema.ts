import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table - storing both administrators and players
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  isAdmin: boolean("is_admin").notNull().default(false),
  credentialCode: text("credential_code").notNull().unique(),
});

// Tournament table
export const tournaments = pgTable("tournaments", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  location: text("location"),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"),
  active: boolean("active").notNull().default(false),
  tournamentType: text("tournament_type").notNull().default("swiss"), // "swiss", "round-robin", "groups-knockout"
  numberOfRounds: integer("number_of_rounds"),
  numberOfBoards: integer("number_of_boards"),
  createdBy: integer("created_by").notNull(),
});

// Groups table
export const groups = pgTable("groups", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  tournamentId: integer("tournament_id").notNull(),
  description: text("description"),
});

// Player-Group relationship table
export const playerGroups = pgTable("player_groups", {
  id: serial("id").primaryKey(),
  playerId: integer("player_id").notNull(),
  groupId: integer("group_id").notNull(),
});

// Matches table
export const matches = pgTable("matches", {
  id: serial("id").primaryKey(), 
  tournamentId: integer("tournament_id").notNull(),
  groupId: integer("group_id"),
  roundNumber: integer("round_number"),
  player1Id: integer("player1_id").notNull(),
  player2Id: integer("player2_id").notNull(),
  player1Score: text("player1_score"),
  player2Score: text("player2_score"),
  matchDate: timestamp("match_date"),
  boardNumber: integer("board_number"),
  completed: boolean("completed").notNull().default(false),
  isFinalStage: boolean("is_final_stage").notNull().default(false),
  finalStageRound: text("final_stage_round"),
});

// Activity Log table
export const activityLogs = pgTable("activity_logs", {
  id: serial("id").primaryKey(),
  tournamentId: integer("tournament_id").notNull(),
  activity: text("activity").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  userId: integer("user_id"),
});

// Create insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  fullName: true,
  isAdmin: true,
  credentialCode: true,
});

export const insertTournamentSchema = createInsertSchema(tournaments).pick({
  name: true,
  description: true,
  location: true,
  startDate: true,
  endDate: true,
  active: true,
  tournamentType: true,
  numberOfRounds: true,
  numberOfBoards: true,
  createdBy: true,
}).extend({
  // Definiamo esplicitamente i valori di enum per il tipo di torneo
  tournamentType: z.enum(["swiss", "round-robin", "groups-knockout"])
});

export const insertGroupSchema = createInsertSchema(groups).pick({
  name: true,
  tournamentId: true,
  description: true,
});

export const insertPlayerGroupSchema = createInsertSchema(playerGroups).pick({
  playerId: true,
  groupId: true,
});

export const insertMatchSchema = createInsertSchema(matches).pick({
  tournamentId: true,
  groupId: true,
  roundNumber: true,
  player1Id: true,
  player2Id: true,
  player1Score: true,
  player2Score: true,
  matchDate: true,
  boardNumber: true,
  completed: true,
  isFinalStage: true,
  finalStageRound: true,
});

export const insertActivityLogSchema = createInsertSchema(activityLogs).pick({
  tournamentId: true,
  activity: true,
  userId: true,
});

// Login schema
export const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

// Match result schema
export const matchResultSchema = z.object({
  matchId: z.number(),
  player1Score: z.string(),
  player2Score: z.string(),
});

// Create types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertTournament = z.infer<typeof insertTournamentSchema>;
export type Tournament = typeof tournaments.$inferSelect;

export type InsertGroup = z.infer<typeof insertGroupSchema>;
export type Group = typeof groups.$inferSelect;

export type InsertPlayerGroup = z.infer<typeof insertPlayerGroupSchema>;
export type PlayerGroup = typeof playerGroups.$inferSelect;

export type InsertMatch = z.infer<typeof insertMatchSchema>;
export type Match = typeof matches.$inferSelect;

export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;
export type ActivityLog = typeof activityLogs.$inferSelect;

export type LoginInput = z.infer<typeof loginSchema>;
export type MatchResultInput = z.infer<typeof matchResultSchema>;

// Match with players and groups expanded
export type MatchWithDetails = Match & {
  player1?: Pick<User, "id" | "fullName" | "credentialCode">;
  player2?: Pick<User, "id" | "fullName" | "credentialCode">;
  group?: Pick<Group, "id" | "name">;
};
