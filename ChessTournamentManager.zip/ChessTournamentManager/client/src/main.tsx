import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Rendering App directly, since it now contains all required providers
createRoot(document.getElementById("root")!).render(<App />);
