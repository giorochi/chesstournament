import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Calendar, Trophy, Star, Info } from "lucide-react";
import { format } from "date-fns";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";

export default function TournamentsList() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [detailsDialogOpen, setDetailsDialogOpen] = useState(false);
  const [selectedTournament, setSelectedTournament] = useState<any>(null);
  
  // Carica la lista dei tornei
  const { data: tournaments, isLoading } = useQuery({
    queryKey: ["/api/tournaments"],
  });
  
  // Carica il torneo attivo
  const { data: activeTournament } = useQuery({
    queryKey: ["/api/tournaments/active"],
  });
  
  // Attiva un torneo selezionato
  const activateTournamentMutation = useMutation({
    mutationFn: async (tournamentId: number) => {
      const res = await apiRequest("POST", `/api/tournaments/${tournamentId}/activate`, {});
      return res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Torneo attivato",
        description: `Il torneo "${data.name}" è ora il torneo attivo`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/tournaments/active"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Errore nell'attivazione del torneo",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const handleActivateTournament = (tournamentId: number) => {
    activateTournamentMutation.mutate(tournamentId);
  };
  
  const handleViewDetails = (tournament: any) => {
    setSelectedTournament(tournament);
    setDetailsDialogOpen(true);
  };
  
  const getTournamentTypeLabel = (type: string) => {
    return type === "swiss" ? "Sistema Svizzero" : "Girone all'italiana";
  };
  
  if (isLoading) {
    return <div className="text-center p-4">Caricamento tornei in corso...</div>;
  }
  
  if (!tournaments || tournaments.length === 0) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle>Tornei</CardTitle>
          <CardDescription>
            Non ci sono tornei creati. Usa il pulsante "Crea Torneo" per iniziare.
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }
  
  return (
    <>
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="flex justify-between items-center">
            <span>Tornei</span>
            {activeTournament && (
              <Badge variant="secondary" className="ml-2 bg-green-100 text-green-800">
                Torneo attivo: {activeTournament.name}
              </Badge>
            )}
          </CardTitle>
          <CardDescription>
            Gestisci i tornei e seleziona quello attivo
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Data Inizio</TableHead>
                  <TableHead>Data Fine</TableHead>
                  <TableHead>Stato</TableHead>
                  <TableHead className="w-[150px]">Azioni</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {tournaments.map((tournament: any) => (
                  <TableRow key={tournament.id}>
                    <TableCell className="font-medium">{tournament.name}</TableCell>
                    <TableCell>{getTournamentTypeLabel(tournament.tournamentType)}</TableCell>
                    <TableCell>{format(new Date(tournament.startDate), "dd/MM/yyyy")}</TableCell>
                    <TableCell>
                      {tournament.endDate ? format(new Date(tournament.endDate), "dd/MM/yyyy") : "Non specificata"}
                    </TableCell>
                    <TableCell>
                      {tournament.active ? (
                        <Badge variant="success" className="bg-green-100 text-green-800">
                          Attivo
                        </Badge>
                      ) : (
                        <Badge variant="outline">Inattivo</Badge>
                      )}
                    </TableCell>
                    <TableCell className="space-x-2">
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="outline"
                              size="icon"
                              onClick={() => handleViewDetails(tournament)}
                            >
                              <Info className="h-4 w-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Dettagli</TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                      
                      {!tournament.active && (
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="outline"
                                size="icon"
                                className="text-amber-600"
                                onClick={() => handleActivateTournament(tournament.id)}
                              >
                                <Star className="h-4 w-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>Attiva Torneo</TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
      
      {/* Dialogo Dettagli Torneo */}
      {selectedTournament && (
        <Dialog open={detailsDialogOpen} onOpenChange={setDetailsDialogOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Trophy className="h-5 w-5 text-amber-500" />
                {selectedTournament.name}
              </DialogTitle>
              <DialogDescription>
                Dettagli del torneo
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="text-sm font-medium text-gray-500">Tipo di Torneo</h4>
                  <p>{getTournamentTypeLabel(selectedTournament.tournamentType)}</p>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-gray-500">Luogo</h4>
                  <p>{selectedTournament.location || "Non specificato"}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-gray-500" />
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Data Inizio</h4>
                    <p>{format(new Date(selectedTournament.startDate), "dd/MM/yyyy")}</p>
                  </div>
                </div>
                
                {selectedTournament.endDate && (
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-gray-500" />
                    <div>
                      <h4 className="text-sm font-medium text-gray-500">Data Fine</h4>
                      <p>{format(new Date(selectedTournament.endDate), "dd/MM/yyyy")}</p>
                    </div>
                  </div>
                )}
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="text-sm font-medium text-gray-500">Numero di Turni</h4>
                  <p>{selectedTournament.numberOfRounds || "Non specificato"}</p>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-gray-500">Numero di Scacchiere</h4>
                  <p>{selectedTournament.numberOfBoards || "Non specificato"}</p>
                </div>
              </div>
              
              {selectedTournament.description && (
                <div>
                  <h4 className="text-sm font-medium text-gray-500">Descrizione</h4>
                  <p className="text-sm mt-1">{selectedTournament.description}</p>
                </div>
              )}
            </div>
            
            <DialogFooter>
              {!selectedTournament.active && (
                <Button
                  onClick={() => {
                    handleActivateTournament(selectedTournament.id);
                    setDetailsDialogOpen(false);
                  }}
                  className="bg-amber-500 hover:bg-amber-600"
                >
                  <Star className="h-4 w-4 mr-2" />
                  Attiva Torneo
                </Button>
              )}
              
              <Button variant="outline" onClick={() => setDetailsDialogOpen(false)}>
                Chiudi
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}