import { SVGProps } from "react";

interface ChessIconProps extends SVGProps<SVGSVGElement> {}

export function ChessIcon({ className, ...props }: ChessIconProps) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      {...props}
    >
      <path d="M12 4c1.657 0 3 1.343 3 3 0 1.13-.639 2.109-1.582 2.607.36.182.652.459.882.788.23.329.4.695.518 1.085.119.39.183.795.183 1.205 0 1.657-1.343 3-3 3s-3-1.343-3-3c0-.41.064-.815.182-1.205a4.05 4.05 0 01.519-1.085c.229-.33.521-.606.881-.788C9.639 9.109 9 8.13 9 7c0-1.657 1.343-3 3-3zM9 17.5c-.828 0-1.5-.672-1.5-1.5S8.172 14.5 9 14.5s1.5.672 1.5 1.5-.672 1.5-1.5 1.5zm6 0c-.828 0-1.5-.672-1.5-1.5s.672-1.5 1.5-1.5 1.5.672 1.5 1.5-.672 1.5-1.5 1.5z" />
    </svg>
  );
}
