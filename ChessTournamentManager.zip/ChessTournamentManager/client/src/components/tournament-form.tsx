import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

// Tournament form schema
const tournamentFormSchema = z.object({
  name: z.string().min(3, "Il nome del torneo deve avere almeno 3 caratteri"),
  description: z.string().optional(),
  location: z.string().min(3, "Inserisci un luogo valido").optional(),
  tournamentType: z.enum(["swiss", "round-robin", "groups-knockout"], {
    required_error: "Seleziona un tipo di torneo",
  }),
  startDate: z.date({
    required_error: "Seleziona la data di inizio",
  }),
  endDate: z.date().optional(),
  numberOfRounds: z.string().transform(v => parseInt(v)).optional(),
  numberOfBoards: z.string().transform(v => parseInt(v)).optional(),
});

type TournamentFormValues = z.infer<typeof tournamentFormSchema>;

interface TournamentFormProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function TournamentForm({ isOpen, onClose }: TournamentFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const form = useForm<TournamentFormValues>({
    resolver: zodResolver(tournamentFormSchema),
    defaultValues: {
      name: "",
      description: "",
      location: "",
      tournamentType: "swiss",
      numberOfRounds: undefined,
      numberOfBoards: undefined,
    },
  });
  
  const createTournamentMutation = useMutation({
    mutationFn: async (data: TournamentFormValues) => {
      // Converti i dati per corrispondere allo schema di backend
      const tournamentData = {
        name: data.name,
        description: data.description || null,
        location: data.location || null,
        startDate: data.startDate.toISOString(), // Converti date esplicitamente
        endDate: data.endDate ? data.endDate.toISOString() : null,
        active: false, // Di default non viene attivato
        tournamentType: data.tournamentType,
        numberOfRounds: data.numberOfRounds || null,
        numberOfBoards: data.numberOfBoards || null,
      };
      
      console.log('Sending tournament data:', tournamentData);
      
      const res = await apiRequest("POST", "/api/tournaments", tournamentData);
      if (!res.ok) {
        const errorData = await res.json();
        console.error('Server error:', errorData);
        throw new Error(errorData.error || 'Failed to create tournament');
      }
      return res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Torneo creato con successo",
        description: `Il torneo "${data.name}" è stato creato`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/tournaments"] });
      form.reset();
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Errore nella creazione del torneo",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (data: TournamentFormValues) => {
    createTournamentMutation.mutate(data);
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Crea Nuovo Torneo</DialogTitle>
          <DialogDescription>
            Inserisci i dettagli per creare un nuovo torneo di scacchi.
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nome Torneo</FormLabel>
                  <FormControl>
                    <Input placeholder="Inserisci il nome del torneo" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="location"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Luogo</FormLabel>
                    <FormControl>
                      <Input placeholder="Luogo del torneo" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="tournamentType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tipo di Torneo</FormLabel>
                    <Select 
                      onValueChange={(value) => {
                        field.onChange(value);
                        if (value === "groups-knockout") {
                          // Resetta il numero di turni quando si seleziona "gironi con fase finale"
                          form.setValue("numberOfRounds", undefined);
                        }
                      }} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Seleziona un tipo" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="swiss">Sistema Svizzero</SelectItem>
                        <SelectItem value="round-robin">Girone all'italiana</SelectItem>
                        <SelectItem value="groups-knockout">Gironi con fase finale</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormDescription>
                      {field.value === "groups-knockout" 
                        ? "Crea gironi personalizzati con fase finale ad eliminazione diretta"
                        : "Il formato del torneo determina come verranno abbinati i giocatori"}
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="startDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Data Inizio</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant={"outline"}
                            className={cn(
                              "w-full pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "dd/MM/yyyy")
                            ) : (
                              <span>Seleziona data</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="endDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Data Fine (opzionale)</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant={"outline"}
                            className={cn(
                              "w-full pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "dd/MM/yyyy")
                            ) : (
                              <span>Seleziona data</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {form.watch("tournamentType") !== "groups-knockout" && (
                <FormField
                  control={form.control}
                  name="numberOfRounds"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Numero di Turni</FormLabel>
                      <FormControl>
                        <Input type="number" min="1" placeholder="Numero di turni" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}
              
              <FormField
                control={form.control}
                name="numberOfBoards"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Numero di Scacchiere</FormLabel>
                    <FormControl>
                      <Input type="number" min="1" placeholder="Numero di scacchiere disponibili" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Descrizione (opzionale)</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Inserisci una descrizione per il torneo" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={onClose}
              >
                Annulla
              </Button>
              <Button 
                type="submit"
                className="bg-[#1976D2] hover:bg-[#004BA0]"
                disabled={createTournamentMutation.isPending}
              >
                {createTournamentMutation.isPending ? "Creazione in corso..." : "Crea Torneo"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}