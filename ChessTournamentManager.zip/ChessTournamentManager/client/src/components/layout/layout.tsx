import { useState, useEffect } from "react";
import Header from "./header";
import AdminSidebar from "./admin-sidebar";
import PlayerSidebar from "./player-sidebar";
import { useAuth } from "@/hooks/use-auth";

export default function Layout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { user } = useAuth();
  
  // Close sidebar on larger screens
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 768) {
        setSidebarOpen(true);
      } else {
        setSidebarOpen(false);
      }
    };
    
    handleResize();
    window.addEventListener("resize", handleResize);
    
    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);
  
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };
  
  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <Header toggleSidebar={toggleSidebar} />
      
      <div className="flex flex-1 overflow-hidden">
        {user?.isAdmin ? (
          <AdminSidebar isOpen={sidebarOpen} toggleSidebar={toggleSidebar} />
        ) : (
          <PlayerSidebar isOpen={sidebarOpen} toggleSidebar={toggleSidebar} />
        )}
        
        <main className="flex-1 overflow-y-auto p-4 relative">
          {children}
        </main>
      </div>
    </div>
  );
}
