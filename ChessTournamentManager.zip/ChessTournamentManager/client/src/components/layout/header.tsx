import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { getUserInitials } from "@/lib/utils";
import { ChessIcon } from "@/components/chess-icon";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";

export default function Header({ toggleSidebar }: { toggleSidebar: () => void }) {
  const [, navigate] = useLocation();
  const { user, logoutMutation } = useAuth();
  
  // Get active tournament if available
  const { data: activeTournament } = useQuery({
    queryKey: ["/api/tournaments/active"],
    enabled: !!user,
  });
  
  const handleLogout = () => {
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        navigate("/auth");
      },
    });
  };
  
  return (
    <header className="bg-[#5D4037] text-[#F5F5DC] shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <ChessIcon className="h-8 w-8" />
          <h1 className="text-xl font-bold hidden sm:block">Chess Tournament Manager</h1>
        </div>
        
        <div className="flex items-center space-x-4">
          {activeTournament && (
            <div className="hidden md:flex items-center space-x-2 px-3 py-1 bg-[#321911] rounded-full text-sm">
              <span>{activeTournament.name}</span>
            </div>
          )}
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                <div className="flex items-center space-x-2">
                  <span className="text-sm font-medium hidden sm:block">
                    {user?.fullName || "User"}
                  </span>
                  <div className="w-8 h-8 rounded-full bg-[#8B6B61] flex items-center justify-center">
                    <span className="text-xs font-bold">
                      {user?.fullName ? getUserInitials(user.fullName) : "U"}
                    </span>
                  </div>
                </div>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem 
                className="cursor-pointer"
                onClick={handleLogout}
                disabled={logoutMutation.isPending}
              >
                Log out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
