import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  LayoutDashboard, 
  Users, 
  FolderKanban, 
  Calendar, 
  BarChart3, 
  LineChart, 
  Menu
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface AdminSidebarProps {
  isOpen: boolean;
  toggleSidebar: () => void;
}

export default function AdminSidebar({ isOpen, toggleSidebar }: AdminSidebarProps) {
  const [location, navigate] = useLocation();
  
  const handleNavigation = (path: string) => {
    navigate(path);
    if (window.innerWidth < 768) {
      toggleSidebar();
    }
  };
  
  const navItems = [
    {
      title: "Dashboard",
      icon: <LayoutDashboard className="h-5 w-5" />,
      path: "/",
      active: location === "/"
    },
    {
      title: "Players",
      icon: <Users className="h-5 w-5" />,
      path: "/admin/players",
      active: location === "/admin/players"
    },
    {
      title: "Groups",
      icon: <FolderKanban className="h-5 w-5" />,
      path: "/admin/groups",
      active: location === "/admin/groups"
    },
    {
      title: "Matches",
      icon: <Calendar className="h-5 w-5" />,
      path: "/admin/matches",
      active: location === "/admin/matches"
    },
    {
      title: "Standings",
      icon: <BarChart3 className="h-5 w-5" />,
      path: "/admin/standings",
      active: location === "/admin/standings"
    },
    {
      title: "Statistics",
      icon: <LineChart className="h-5 w-5" />,
      path: "/admin/statistics",
      active: location === "/admin/statistics"
    }
  ];
  
  return (
    <>
      <aside className={cn(
        "bg-white w-64 shadow-md flex-shrink-0 overflow-y-auto fixed inset-y-0 left-0 z-20 transition-transform duration-200 ease-in-out transform md:relative md:translate-x-0",
        isOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="p-4 border-b">
          <h2 className="font-bold text-[#5D4037]">Admin Dashboard</h2>
        </div>
        <nav className="p-2">
          <ul>
            {navItems.map((item) => (
              <li key={item.path} className="mb-1">
                <button
                  className={cn(
                    "flex items-center space-x-2 p-3 rounded-md w-full text-left transition duration-200",
                    item.active 
                      ? "bg-[#5D4037] bg-opacity-10 text-[#5D4037]" 
                      : "hover:bg-gray-100"
                  )}
                  onClick={() => handleNavigation(item.path)}
                >
                  {item.icon}
                  <span>{item.title}</span>
                </button>
              </li>
            ))}
          </ul>
        </nav>
      </aside>
      
      {/* Mobile Menu Toggle */}
      <Button
        variant="default"
        size="icon"
        className="fixed bottom-6 right-6 bg-[#5D4037] text-white rounded-full shadow-lg md:hidden z-30"
        onClick={toggleSidebar}
      >
        <Menu className="h-6 w-6" />
      </Button>
    </>
  );
}
