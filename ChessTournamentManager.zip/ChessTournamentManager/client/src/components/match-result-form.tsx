import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { MatchWithDetails, matchResultSchema } from "@shared/schema";
import { getUserInitials } from "@/lib/utils";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";

// Extended schema with validation for chess results
const resultFormSchema = z.object({
  matchId: z.number(),
  result: z.enum(["player1Win", "player2Win", "draw"]),
});

type ResultFormValues = z.infer<typeof resultFormSchema>;

interface MatchResultFormProps {
  isOpen: boolean;
  onClose: () => void;
  match?: MatchWithDetails;
}

export default function MatchResultForm({ isOpen, onClose, match }: MatchResultFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Error state if match is not provided
  if (!match) {
    return null;
  }
  
  const form = useForm<ResultFormValues>({
    resolver: zodResolver(resultFormSchema),
    defaultValues: {
      matchId: match.id,
      result: "draw", // Default to draw
    },
  });

  // Update match result mutation
  const updateResultMutation = useMutation({
    mutationFn: async (data: ResultFormValues) => {
      // Convert result to appropriate player scores
      let player1Score = "0";
      let player2Score = "0";
      
      if (data.result === "player1Win") {
        player1Score = "1";
        player2Score = "0";
      } else if (data.result === "player2Win") {
        player1Score = "0";
        player2Score = "1";
      } else {
        player1Score = "0.5";
        player2Score = "0.5";
      }
      
      const res = await apiRequest("PATCH", `/api/matches/${data.matchId}/result`, {
        player1Score,
        player2Score,
      });
      
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Match result recorded",
        description: "The match result has been saved successfully.",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/tournaments/${match.tournamentId}/matches`] });
      form.reset();
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to record result",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (values: ResultFormValues) => {
    updateResultMutation.mutate(values);
  };

  // Make sure we have player data
  if (!match.player1 || !match.player2) {
    return null;
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Enter Match Result</DialogTitle>
          <DialogDescription>
            Record the outcome of the match between {match.player1.fullName} and {match.player2.fullName}.
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-3 gap-4 items-center justify-center mb-6">
              <div className="flex flex-col items-center">
                <div className="w-12 h-12 rounded-full bg-[#8B6B61] flex items-center justify-center text-white text-lg mb-2">
                  {getUserInitials(match.player1.fullName)}
                </div>
                <div className="text-center font-medium truncate max-w-full">
                  {match.player1.fullName}
                </div>
              </div>
              
              <div className="text-center text-lg font-bold">
                vs
              </div>
              
              <div className="flex flex-col items-center">
                <div className="w-12 h-12 rounded-full bg-[#8B6B61] flex items-center justify-center text-white text-lg mb-2">
                  {getUserInitials(match.player2.fullName)}
                </div>
                <div className="text-center font-medium truncate max-w-full">
                  {match.player2.fullName}
                </div>
              </div>
            </div>
            
            <FormField
              control={form.control}
              name="result"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Match Result</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="flex flex-col space-y-2"
                    >
                      <div className="flex items-center space-x-2 rounded-md border p-3">
                        <RadioGroupItem value="player1Win" id="player1Win" />
                        <Label htmlFor="player1Win" className="flex-1">
                          {match.player1.fullName} wins (1-0)
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2 rounded-md border p-3">
                        <RadioGroupItem value="player2Win" id="player2Win" />
                        <Label htmlFor="player2Win" className="flex-1">
                          {match.player2.fullName} wins (0-1)
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2 rounded-md border p-3">
                        <RadioGroupItem value="draw" id="draw" />
                        <Label htmlFor="draw" className="flex-1">
                          Draw (½-½)
                        </Label>
                      </div>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={onClose}
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                className="bg-[#1976D2] hover:bg-[#004BA0]"
                disabled={updateResultMutation.isPending}
              >
                {updateResultMutation.isPending ? "Saving..." : "Save Result"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
