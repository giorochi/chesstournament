import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Calendar } from "@/components/ui/calendar";
import { CalendarIcon } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

// Form schema for creating pairings
const pairingFormSchema = z.object({
  groupId: z.string().min(1, "Group is required"),
  roundNumber: z.string().min(1, "Round number is required"),
  matchDate: z.date().optional(),
  isFinalStage: z.boolean().default(false),
  finalStageRound: z.string().optional(),
});

type PairingFormValues = z.infer<typeof pairingFormSchema>;

interface PairingGeneratorProps {
  isOpen: boolean;
  onClose: () => void;
  tournamentId?: number;
}

export default function PairingGenerator({ isOpen, onClose, tournamentId }: PairingGeneratorProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [matchDate, setMatchDate] = useState<Date | undefined>(undefined);
  
  // Get groups for the tournament
  const { data: groups = [] } = useQuery({
    queryKey: [`/api/tournaments/${tournamentId}/groups`],
    enabled: !!tournamentId,
  });

  // Get players for selected group
  const [selectedGroup, setSelectedGroup] = useState<string>("");
  const { data: groupPlayers = [] } = useQuery({
    queryKey: [`/api/groups/${selectedGroup}/players`],
    enabled: !!selectedGroup,
  });

  const form = useForm<PairingFormValues>({
    resolver: zodResolver(pairingFormSchema),
    defaultValues: {
      groupId: "",
      roundNumber: "1",
      isFinalStage: false,
      finalStageRound: "",
    },
  });

  // Watch for final stage selection to conditionally show the round selector
  const isFinalStage = form.watch("isFinalStage");

  // Create pairings mutation
  const createPairingsMutation = useMutation({
    mutationFn: async (data: any) => {
      // For each pairing, create a match
      const matchPromises = data.pairings.map((pairing: any) => {
        const matchData = {
          tournamentId: tournamentId,
          groupId: isFinalStage ? null : parseInt(data.groupId),
          roundNumber: isFinalStage ? null : parseInt(data.roundNumber),
          player1Id: pairing.player1Id,
          player2Id: pairing.player2Id,
          matchDate: data.matchDate ? data.matchDate.toISOString() : null,
          isFinalStage: data.isFinalStage,
          finalStageRound: data.isFinalStage ? data.finalStageRound : null,
          completed: false,
        };
        
        return apiRequest("POST", "/api/matches", matchData);
      });
      
      return Promise.all(matchPromises);
    },
    onSuccess: () => {
      toast({
        title: "Pairings generated",
        description: `${isFinalStage ? "Final stage" : "Group"} pairings have been created successfully`,
      });
      queryClient.invalidateQueries({ queryKey: [`/api/tournaments/${tournamentId}/matches`] });
      form.reset();
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to generate pairings",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Generate round-robin pairings for a group
  const generateRoundRobinPairings = (players: any[], roundNumber: number) => {
    // Simple round robin algorithm
    // For demonstration, we'll pair players by index for different rounds
    const pairings = [];
    const playersCopy = [...players];
    
    // If odd number of players, add a "bye" player
    if (playersCopy.length % 2 !== 0) {
      playersCopy.push({ id: -1, fullName: "BYE" });
    }
    
    const n = playersCopy.length;
    
    // For round robin, we need n-1 rounds
    if (roundNumber > n - 1) {
      roundNumber = ((roundNumber - 1) % (n - 1)) + 1;
    }
    
    // Rotate players for different rounds
    // Keep player 0 fixed, rotate others
    const rotatedPlayers = [
      playersCopy[0],
      ...playersCopy.slice(1).map((_, i) => {
        const idx = (i + roundNumber - 1) % (n - 1) + 1;
        return playersCopy[idx];
      }),
    ];
    
    // Create pairings
    for (let i = 0; i < n / 2; i++) {
      // Skip pairing with "bye" player
      if (rotatedPlayers[i].id !== -1 && rotatedPlayers[n - 1 - i].id !== -1) {
        pairings.push({
          player1Id: rotatedPlayers[i].id,
          player2Id: rotatedPlayers[n - 1 - i].id,
          player1Name: rotatedPlayers[i].fullName,
          player2Name: rotatedPlayers[n - 1 - i].fullName,
        });
      }
    }
    
    return pairings;
  };

  // Generate bracket pairings for final stages
  const generateBracketPairings = (players: any[], round: string) => {
    const pairings = [];
    
    // Determine how many matches based on the round
    let matchCount = 0;
    let startRank = 0;
    
    if (round === "quarter-final") {
      matchCount = 4;
    } else if (round === "semi-final") {
      matchCount = 2;
      startRank = 4; // Skip first 4 players who should be in quarter finals
    } else if (round === "final") {
      matchCount = 1;
      startRank = 6; // Skip first 6 players who should be in earlier rounds
    }
    
    // Sort players by rank for seeding
    const sortedPlayers = [...players].sort((a, b) => {
      const rankA = a.rank || 999;
      const rankB = b.rank || 999;
      return rankA - rankB;
    });
    
    // Create pairings based on seeding
    for (let i = 0; i < matchCount; i++) {
      const player1Idx = startRank + i;
      const player2Idx = startRank + matchCount * 2 - 1 - i;
      
      if (player1Idx < sortedPlayers.length && player2Idx < sortedPlayers.length) {
        pairings.push({
          player1Id: sortedPlayers[player1Idx].id,
          player2Id: sortedPlayers[player2Idx].id,
          player1Name: sortedPlayers[player1Idx].fullName,
          player2Name: sortedPlayers[player2Idx].fullName,
        });
      }
    }
    
    return pairings;
  };

  const onSubmit = (values: PairingFormValues) => {
    let pairings;
    
    if (values.isFinalStage) {
      // For final stage, we need to get all players and seed them based on standings
      const allPlayers = groups.flatMap((group: any) => 
        groupPlayers.filter((player: any) => 
          player.rank && player.rank <= 2
        )
      );
      
      pairings = generateBracketPairings(allPlayers, values.finalStageRound || "");
    } else {
      // For regular group stage
      pairings = generateRoundRobinPairings(groupPlayers, parseInt(values.roundNumber));
    }
    
    if (pairings.length === 0) {
      toast({
        title: "No pairings generated",
        description: "There are not enough players to create pairings",
        variant: "destructive",
      });
      return;
    }
    
    // Submit the pairings
    createPairingsMutation.mutate({
      ...values,
      pairings,
      matchDate: matchDate,
      tournamentId,
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Generate Match Pairings</DialogTitle>
          <DialogDescription>
            Create pairings for the next round of matches in your tournament.
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="isFinalStage"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>Final Stage Matches</FormLabel>
                    <FormDescription>
                      Check this if you're creating knockout stage matches
                    </FormDescription>
                  </div>
                </FormItem>
              )}
            />
            
            {isFinalStage ? (
              <FormField
                control={form.control}
                name="finalStageRound"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Final Stage Round</FormLabel>
                    <Select onValueChange={(value) => {
                      field.onChange(value);
                      // Set groupId to empty since it's not needed for final stage
                      form.setValue("groupId", "");
                    }}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select round" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="quarter-final">Quarter Finals</SelectItem>
                        <SelectItem value="semi-final">Semi Finals</SelectItem>
                        <SelectItem value="final">Final</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            ) : (
              <>
                <FormField
                  control={form.control}
                  name="groupId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Group</FormLabel>
                      <Select 
                        onValueChange={(value) => {
                          field.onChange(value);
                          setSelectedGroup(value);
                        }}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a group" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {groups.map((group: any) => (
                            <SelectItem key={group.id} value={group.id.toString()}>
                              {group.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="roundNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Round Number</FormLabel>
                      <FormControl>
                        <Input type="number" min="1" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </>
            )}
            
            <FormItem className="flex flex-col">
              <FormLabel>Match Date (Optional)</FormLabel>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant={"outline"}
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !matchDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {matchDate ? format(matchDate, "PPP") : "Pick a date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={matchDate}
                    onSelect={setMatchDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
              <FormDescription>
                Set a date for all matches in this round
              </FormDescription>
            </FormItem>
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={onClose}
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                className="bg-[#1976D2] hover:bg-[#004BA0]"
                disabled={createPairingsMutation.isPending}
              >
                {createPairingsMutation.isPending ? "Generating..." : "Generate Pairings"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
