import { useQuery } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Check, UserPlus, Clock, Activity } from "lucide-react";

interface ActivityLogProps {
  tournamentId: number;
  limit?: number;
}

export default function ActivityLog({ tournamentId, limit = 3 }: ActivityLogProps) {
  const { data: activities, isLoading } = useQuery({
    queryKey: [`/api/tournaments/${tournamentId}/activity`, { limit }],
    enabled: !!tournamentId,
  });
  
  if (isLoading) {
    return (
      <Card className="overflow-hidden">
        <CardHeader className="bg-[#8B6B61] p-4 text-white flex justify-between items-center">
          <CardTitle className="font-bold">Recent Activity</CardTitle>
        </CardHeader>
        <CardContent className="p-4">
          <div className="flex justify-center items-center p-4">
            <p>Loading activity logs...</p>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  if (!activities || activities.length === 0) {
    return (
      <Card className="overflow-hidden">
        <CardHeader className="bg-[#8B6B61] p-4 text-white flex justify-between items-center">
          <CardTitle className="font-bold">Recent Activity</CardTitle>
        </CardHeader>
        <CardContent className="p-4">
          <div className="flex justify-center items-center p-4">
            <p>No recent activity</p>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  const getActivityIcon = (activity: string) => {
    if (activity.includes('result')) {
      return (
        <div className="flex-shrink-0 w-10 h-10 rounded-full bg-green-100 flex items-center justify-center mr-3">
          <Check className="h-5 w-5 text-[#4CAF50]" />
        </div>
      );
    } else if (activity.includes('registered') || activity.includes('added') || activity.includes('assigned')) {
      return (
        <div className="flex-shrink-0 w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
          <UserPlus className="h-5 w-5 text-[#1976D2]" />
        </div>
      );
    } else if (activity.includes('pairings') || activity.includes('created')) {
      return (
        <div className="flex-shrink-0 w-10 h-10 rounded-full bg-yellow-100 flex items-center justify-center mr-3">
          <Clock className="h-5 w-5 text-[#FFC107]" />
        </div>
      );
    } else {
      return (
        <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center mr-3">
          <Activity className="h-5 w-5 text-gray-500" />
        </div>
      );
    }
  };
  
  return (
    <Card className="overflow-hidden">
      <CardHeader className="bg-[#8B6B61] p-4 text-white flex justify-between items-center">
        <CardTitle className="font-bold">Recent Activity</CardTitle>
        <button className="text-sm text-white hover:text-[#F5F5DC]">View All</button>
      </CardHeader>
      <CardContent className="divide-y p-0">
        {activities.map((activity) => (
          <div key={activity.id} className="flex items-start p-4">
            {getActivityIcon(activity.activity)}
            <div>
              <p className="font-medium">{activity.activity.split(':')[0]}</p>
              {activity.activity.includes(':') && (
                <p className="text-sm text-gray-600">{activity.activity.split(':')[1].trim()}</p>
              )}
              <p className="text-xs text-gray-500 mt-1">
                {formatDistanceToNow(new Date(activity.timestamp), { addSuffix: true })}
              </p>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
