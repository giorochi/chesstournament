import { useState } from "react";
import { cn } from "@/lib/utils";
import { MatchWithDetails } from "@shared/schema";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { getUserInitials, formatMatchDate } from "@/lib/utils";

interface TournamentBracketProps {
  tournamentId: number;
  finalMatches: MatchWithDetails[];
  groupOptions: { value: string; label: string }[];
}

export default function TournamentBracket({ 
  tournamentId, 
  finalMatches, 
  groupOptions 
}: TournamentBracketProps) {
  const [selectedGroup, setSelectedGroup] = useState("all");
  
  // Filter matches by round
  const finalRound = finalMatches.filter(m => m.finalStageRound === 'final');
  const semiFinals = finalMatches.filter(m => m.finalStageRound === 'semi-final');
  const quarterFinals = finalMatches.filter(m => m.finalStageRound === 'quarter-final');
  
  const handleGroupChange = (value: string) => {
    setSelectedGroup(value);
  };
  
  return (
    <Card className="overflow-hidden">
      <CardHeader className="bg-[#5D4037] text-[#F5F5DC] flex flex-row justify-between items-center">
        <CardTitle className="font-bold">Final Rounds Bracket</CardTitle>
        <div>
          <Select value={selectedGroup} onValueChange={handleGroupChange}>
            <SelectTrigger className="text-gray-800 text-sm bg-[#F5F5DC] w-[120px] h-8">
              <SelectValue placeholder="All Groups" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Groups</SelectItem>
              {groupOptions.map(group => (
                <SelectItem key={group.value} value={group.value}>
                  {group.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent className="p-4">
        <ScrollArea className="w-full" type="always">
          <div className="min-w-[900px] p-2">
            {/* Final Round */}
            <div className="flex justify-center items-center h-64">
              <BracketMatch 
                match={finalRound[0]} 
                title="Final" 
              />
            </div>

            {/* Semi Finals */}
            <div className="flex justify-center items-center h-64 -mt-32">
              <div className="flex justify-between w-full px-20">
                <BracketMatch 
                  match={semiFinals[0]} 
                  title="Semi Final 1" 
                  connectorSide="right"
                />
                <BracketMatch 
                  match={semiFinals[1]} 
                  title="Semi Final 2" 
                  connectorSide="left"
                />
              </div>
            </div>

            {/* Quarter Finals */}
            <div className="flex justify-around items-center h-64 -mt-32">
              <BracketMatch 
                match={quarterFinals[0]} 
                title="Quarter Final 1" 
                connectorSide="right"
              />
              <BracketMatch 
                match={quarterFinals[1]} 
                title="Quarter Final 2" 
                connectorSide="right"
              />
              <BracketMatch 
                match={quarterFinals[2]} 
                title="Quarter Final 3" 
                connectorSide="left"
              />
              <BracketMatch 
                match={quarterFinals[3]} 
                title="Quarter Final 4" 
                connectorSide="left"
              />
            </div>
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}

interface BracketMatchProps {
  match?: MatchWithDetails;
  title: string;
  connectorSide?: "left" | "right";
}

function BracketMatch({ match, title, connectorSide }: BracketMatchProps) {
  const connectorClasses = cn(
    "absolute top-1/2",
    connectorSide === "right" && "right-0",
    connectorSide === "left" && "left-0"
  );
  
  const matchParticipants = match?.player1 && match?.player2
    ? `${match.player1.fullName} vs ${match.player2.fullName}`
    : "TBD vs TBD";
  
  const matchDateTime = match?.matchDate
    ? formatMatchDate(match.matchDate)
    : "Not yet scheduled";
  
  return (
    <div className="relative w-40 h-24 border-2 border-[#5D4037] rounded-lg bg-[#F5F5DC]">
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="text-center font-bold">{title}</div>
        <div className="text-center text-gray-500 text-sm">{matchParticipants}</div>
        <div className="text-center text-xs text-gray-400">{matchDateTime}</div>
      </div>
      
      {connectorSide && (
        <div className={connectorClasses}>
          <div className="w-20 h-0.5 bg-[#5D4037]"></div>
        </div>
      )}
    </div>
  );
}
