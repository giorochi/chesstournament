import { getUserInitials, getMatchResultStatus, formatMatchDate } from "@/lib/utils";
import { cn } from "@/lib/utils";
import { MatchWithDetails } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { MapPin } from "lucide-react";

interface MatchCardProps {
  match: MatchWithDetails;
  isNextMatch?: boolean;
}

export default function MatchCard({ match, isNextMatch = false }: MatchCardProps) {
  const { user } = useAuth();
  
  if (!match.player1 || !match.player2) {
    return null;
  }
  
  const isAdmin = user?.isAdmin || false;
  const currentPlayerId = user?.id;
  
  // Determine status for players
  const player1Status = currentPlayerId 
    ? getMatchResultStatus(currentPlayerId, match) 
    : match.completed
      ? getMatchResultStatus(match.player1Id, match)
      : 'pending';
  
  // Only show result status colors when the match is completed
  const showResultStatus = match.completed;
  
  // Determine board display
  const boardInfo = match.boardNumber ? `Board ${match.boardNumber}` : 'TBD';
  const groupInfo = match.group ? match.group.name : 'Final Stage';
  const finalRound = match.finalStageRound 
    ? match.finalStageRound.charAt(0).toUpperCase() + match.finalStageRound.slice(1)
    : '';
  
  const boardDisplay = finalRound 
    ? `${finalRound} • ${boardInfo}`
    : `${groupInfo} • ${boardInfo}`;
  
  // Determine player piece color (if current user is playing)
  let pieceColor = "";
  if (currentPlayerId && !isAdmin) {
    if (match.player1Id === currentPlayerId) {
      pieceColor = "White Pieces";
    } else if (match.player2Id === currentPlayerId) {
      pieceColor = "Black Pieces";
    }
  }
  
  return (
    <Card className={cn(
      "overflow-hidden transition-shadow hover:shadow-md",
      isNextMatch && "border-2 border-[#1976D2]"
    )}>
      <CardContent className={cn("p-4", isNextMatch && "pt-6")}>
        {isNextMatch && (
          <div className="text-center mb-4">
            <Badge variant="default" className="bg-[#FFD700] text-[#5D4037] hover:bg-[#F0C800]">
              {match.matchDate ? formatMatchDate(match.matchDate) : "Not scheduled"} • {boardInfo}
            </Badge>
          </div>
        )}
        
        {!isNextMatch && (
          <div className="flex justify-between items-center mb-2">
            <Badge 
              variant="outline" 
              className="bg-[#5D4037] bg-opacity-10 text-[#5D4037] hover:bg-opacity-15"
            >
              {boardDisplay}
            </Badge>
            <span className="text-xs text-gray-500">
              {match.matchDate ? formatMatchDate(match.matchDate) : "Not scheduled"}
            </span>
          </div>
        )}
        
        <div className={cn(
          "flex justify-between items-center",
          isNextMatch ? "flex-col sm:flex-row gap-4" : ""
        )}>
          <div className={cn(
            "flex items-center",
            isNextMatch ? "flex-col items-center mb-4 sm:mb-0" : "space-x-2"
          )}>
            <div className={cn(
              "w-8 h-8 bg-[#8B6B61] rounded-full flex items-center justify-center text-white text-xs",
              isNextMatch && "w-16 h-16 text-xl mb-2"
            )}>
              {getUserInitials(match.player1.fullName)}
            </div>
            <div className={cn("", isNextMatch && "text-center")}>
              <div className="font-medium">{match.player1.fullName}</div>
              {isNextMatch && currentPlayerId === match.player1Id && (
                <div className="text-sm text-gray-600">You</div>
              )}
            </div>
          </div>
          
          <div className={cn(
            "font-medium",
            isNextMatch && "flex flex-col items-center mb-4 sm:mb-0"
          )}>
            {match.completed ? (
              <div className="text-sm font-bold">
                {match.player1Score} - {match.player2Score}
              </div>
            ) : (
              <div className={cn(
                "text-sm text-gray-600",
                isNextMatch && "font-bold text-2xl text-[#5D4037]"
              )}>
                VS
              </div>
            )}
            {isNextMatch && (
              <div className="chessboard-pattern w-10 h-10 rounded-md mt-2 bg-[#5D4037] bg-opacity-10"></div>
            )}
          </div>
          
          <div className={cn(
            "flex items-center",
            isNextMatch ? "flex-col items-center" : "space-x-2"
          )}>
            {!isNextMatch && (
              <span className="font-medium">{match.player2.fullName}</span>
            )}
            <div className={cn(
              "w-8 h-8 bg-[#8B6B61] rounded-full flex items-center justify-center text-white text-xs",
              isNextMatch && "w-16 h-16 text-xl mb-2"
            )}>
              {getUserInitials(match.player2.fullName)}
            </div>
            {isNextMatch && (
              <div className="text-center">
                <div className="font-medium">{match.player2.fullName}</div>
                {isNextMatch && currentPlayerId === match.player2Id && (
                  <div className="text-sm text-gray-600">You</div>
                )}
              </div>
            )}
          </div>
        </div>
        
        {isNextMatch && match.boardNumber && (
          <div className="mt-6 text-center">
            <div className="inline-block bg-[#8B6B61] text-white px-4 py-2 rounded-md">
              <div className="flex items-center space-x-2">
                <MapPin className="h-5 w-5" />
                <span>Board {match.boardNumber} - {pieceColor}</span>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
