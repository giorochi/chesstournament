import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { getUserInitials, calculateWinPercentage } from "@/lib/utils";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

interface PlayerStatsProps {
  playerId?: number;
  tournamentId: number;
}

export default function PlayerStats({ playerId, tournamentId }: PlayerStatsProps) {
  const { user } = useAuth();
  const id = playerId || user?.id;
  
  const { data: stats, isLoading } = useQuery({
    queryKey: [`/api/players/${id}/statistics`, { tournamentId }],
    enabled: !!id && !!tournamentId,
  });
  
  const { data: playerData } = useQuery({
    queryKey: [`/api/players/${id}`],
    enabled: !!id,
  });
  
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Loading player statistics...</CardTitle>
        </CardHeader>
      </Card>
    );
  }
  
  if (!stats) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>No statistics available</CardTitle>
        </CardHeader>
      </Card>
    );
  }
  
  const playerName = playerData?.fullName || user?.fullName || "Player";
  const winPercentage = calculateWinPercentage(stats.wins, stats.played);
  
  return (
    <Card className="overflow-hidden">
      <CardHeader className="bg-[#5D4037] p-6 text-[#F5F5DC]">
        <div className="flex flex-col md:flex-row md:justify-between md:items-center">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 rounded-full bg-[#8B6B61] flex items-center justify-center text-xl font-bold">
              {getUserInitials(playerName)}
            </div>
            <div>
              <CardTitle className="text-2xl font-bold">{playerName}</CardTitle>
              <p className="text-[#F5F5DC] text-opacity-80">Player ID: #{id}</p>
            </div>
          </div>
          
          {playerData?.group && (
            <div className="mt-4 md:mt-0 flex items-center space-x-2 bg-[#321911] rounded-lg px-4 py-2">
              <FolderIcon className="h-5 w-5" />
              <span>{playerData.group.name}</span>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <StatsCard title="Matches Played" value={stats.played} />
          <StatsCard title="Wins" value={stats.wins} />
          <StatsCard title="Points" value={stats.points} />
        </div>
        
        {stats.played > 0 && (
          <div className="mt-6">
            <div className="mb-2">
              <span className="text-sm text-gray-600">Win Percentage</span>
              <div className="flex justify-between">
                <span className="text-lg font-semibold">{winPercentage}%</span>
                <span className="text-sm text-gray-500">
                  {stats.wins} wins, {stats.draws} draws, {stats.losses} losses
                </span>
              </div>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div 
                className="bg-[#1976D2] h-2.5 rounded-full" 
                style={{ width: `${winPercentage}%` }}
              ></div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function StatsCard({ title, value }: { title: string; value: number }) {
  return (
    <div className="bg-gray-100 rounded-lg p-4 text-center">
      <div className="text-sm text-gray-600 mb-1">{title}</div>
      <div className="text-2xl font-bold">{value}</div>
    </div>
  );
}

function FolderIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"></path>
    </svg>
  );
}
