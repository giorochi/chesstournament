import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { getUserInitials } from "@/lib/utils";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";

interface GroupStandingTableProps {
  groupId: number;
  groupName: string;
}

export default function GroupStandingTable({ groupId, groupName }: GroupStandingTableProps) {
  const { user } = useAuth();
  
  const { data: standings, isLoading } = useQuery({
    queryKey: [`/api/groups/${groupId}/standings`],
    enabled: !!groupId,
  });
  
  if (isLoading) {
    return (
      <Card className="overflow-hidden">
        <CardHeader className="bg-[#8B6B61] text-white">
          <CardTitle className="font-bold">{groupName} Standing</CardTitle>
        </CardHeader>
        <CardContent className="p-4">
          <div className="flex justify-center items-center p-8">
            <p>Loading standings...</p>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  if (!standings || standings.length === 0) {
    return (
      <Card className="overflow-hidden">
        <CardHeader className="bg-[#8B6B61] text-white">
          <CardTitle className="font-bold">{groupName} Standing</CardTitle>
        </CardHeader>
        <CardContent className="p-4">
          <div className="flex justify-center items-center p-8">
            <p>No standings available for this group.</p>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card className="overflow-hidden">
      <CardHeader className="bg-[#8B6B61] text-white flex justify-between items-center">
        <CardTitle className="font-bold">{groupName} Standing</CardTitle>
      </CardHeader>
      <CardContent className="p-4">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader className="bg-gray-100">
              <TableRow>
                <TableHead className="text-left">Rank</TableHead>
                <TableHead className="text-left">Player</TableHead>
                <TableHead className="text-left">Played</TableHead>
                <TableHead className="text-left">W</TableHead>
                <TableHead className="text-left">D</TableHead>
                <TableHead className="text-left">L</TableHead>
                <TableHead className="text-left">Points</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {standings.map((standing: any) => (
                <TableRow 
                  key={standing.playerId}
                  className={standing.playerId === user?.id ? "bg-[#F5F5DC] bg-opacity-50" : "hover:bg-gray-50"}
                >
                  <TableCell className="font-medium">{standing.rank}</TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-8 w-8 rounded-full bg-[#8B6B61] flex items-center justify-center text-white text-xs">
                        {getUserInitials(standing.playerName)}
                      </div>
                      <div className="ml-3">
                        <div className="text-sm font-medium">{standing.playerName}</div>
                        {standing.playerId === user?.id && (
                          <div className="text-xs text-gray-500">You</div>
                        )}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>{standing.played}</TableCell>
                  <TableCell>{standing.wins}</TableCell>
                  <TableCell>{standing.draws}</TableCell>
                  <TableCell>{standing.losses}</TableCell>
                  <TableCell>
                    <span className="px-3 py-1 inline-flex text-sm leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                      {standing.points}
                    </span>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <div className="mt-4 pt-4 border-t border-gray-200">
          <div className="text-sm text-gray-600">
            <span className="font-medium">Top 2</span> from each group advance to quarter-finals
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
