import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Get user initials from full name
export function getUserInitials(fullName: string): string {
  return fullName
    .split(' ')
    .map(name => name[0]?.toUpperCase() || '')
    .join('');
}

// Chess match result utilities
export function getMatchResult(player1Score?: string, player2Score?: string): string {
  if (!player1Score || !player2Score) return "Not played";
  
  return `${player1Score} - ${player2Score}`;
}

export function getMatchResultStatus(playerId: number, match: any): 'win' | 'loss' | 'draw' | 'pending' {
  if (!match.completed) return 'pending';
  
  const isPlayer1 = match.player1Id === playerId;
  const score1 = parseFloat(match.player1Score || '0');
  const score2 = parseFloat(match.player2Score || '0');
  
  if (score1 === score2) return 'draw';
  
  if (isPlayer1) {
    return score1 > score2 ? 'win' : 'loss';
  } else {
    return score2 > score1 ? 'win' : 'loss';
  }
}

export function formatMatchDate(dateString?: string | Date): string {
  if (!dateString) return 'Not scheduled';
  
  const date = new Date(dateString);
  return date.toLocaleString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

// Tournament statistics utilities
export function calculateWinPercentage(wins: number, played: number): number {
  if (played === 0) return 0;
  return Math.round((wins / played) * 100);
}

// Group final stages utilities
export type RoundName = 'quarter-final' | 'semi-final' | 'final';

export function getRoundDisplayName(roundName: RoundName, matchNumber?: number): string {
  if (roundName === 'quarter-final' && matchNumber) {
    return `Quarter Final ${matchNumber}`;
  } else if (roundName === 'semi-final' && matchNumber) {
    return `Semi Final ${matchNumber}`;
  } else if (roundName === 'final') {
    return 'Final';
  }
  
  return roundName.replace('-', ' ');
}

// Generate Chess themed colors
export const chessColors = {
  primary: {
    light: '#8B6B61',
    DEFAULT: '#5D4037',
    dark: '#321911',
  },
  secondary: {
    light: '#63A4FF',
    DEFAULT: '#1976D2',
    dark: '#004BA0',
  },
  cream: '#F5F5DC',
  gold: '#FFD700',
  success: '#4CAF50',
  warning: '#FFC107',
  danger: '#F44336',
};
