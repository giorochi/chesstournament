import { useState } from "react";
import { createRoot } from "react-dom/client";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { AuthProvider } from "./hooks/use-auth";
import { ThemeProvider } from "next-themes";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Toaster } from "@/components/ui/toaster";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "./hooks/use-auth";

// Simple login form that doesn't use complex routing
function LoginTestForm() {
  const { loginMutation, registerMutation, user, logoutMutation } = useAuth();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [isRegistering, setIsRegistering] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isRegistering) {
      registerMutation.mutate({
        username,
        password,
        fullName,
        isAdmin: true,
        credentialCode: "",
      });
    } else {
      loginMutation.mutate({ username, password });
    }
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  if (user) {
    return (
      <Card className="w-full max-w-md mx-auto mt-10">
        <CardHeader>
          <CardTitle>Logged In Successfully</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p>Welcome, {user.fullName}!</p>
            <p>You are logged in as: {user.isAdmin ? "Administrator" : "Player"}</p>
            <Button onClick={handleLogout}>Logout</Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-md mx-auto mt-10">
      <CardHeader>
        <CardTitle>{isRegistering ? "Register" : "Login"}</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {isRegistering && (
            <div className="space-y-2">
              <label htmlFor="fullName">Full Name</label>
              <Input
                id="fullName"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Enter your full name"
                required
              />
            </div>
          )}
          <div className="space-y-2">
            <label htmlFor="username">Username</label>
            <Input
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Enter your username"
              required
            />
          </div>
          <div className="space-y-2">
            <label htmlFor="password">Password</label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter your password"
              required
            />
          </div>
          <div className="pt-2 flex justify-between">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsRegistering(!isRegistering)}
            >
              {isRegistering ? "Switch to Login" : "Switch to Register"}
            </Button>
            <Button type="submit">
              {isRegistering ? "Register" : "Login"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}

// Simple wrapper component
function LoginTest() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider attribute="class" defaultTheme="light">
        <AuthProvider>
          <TooltipProvider>
            <div className="min-h-screen bg-gray-100 p-4">
              <h1 className="text-2xl font-bold text-center mb-6">
                Chess Tournament Manager - Login Test
              </h1>
              <LoginTestForm />
            </div>
            <Toaster />
          </TooltipProvider>
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

// For testing only
if (import.meta.env.DEV) {
  const root = document.getElementById("root");
  if (root) {
    createRoot(root).render(<LoginTest />);
  }
}

export default LoginTest;