import { Switch, Route } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { ProtectedRoute } from "./lib/protected-route";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import { createRoot } from "react-dom/client";
import { AuthProvider } from "./hooks/use-auth";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { ThemeProvider } from "next-themes";
import { Toaster } from "@/components/ui/toaster";

// Admin pages
import AdminDashboard from "@/pages/admin/dashboard";
import AdminPlayers from "@/pages/admin/players";
import AdminGroups from "@/pages/admin/groups";
import AdminMatches from "@/pages/admin/matches";
import AdminStandings from "@/pages/admin/standings";
import AdminStatistics from "@/pages/admin/statistics";

// Player pages
import PlayerDashboard from "@/pages/player/dashboard";
import PlayerMatches from "@/pages/player/matches";
import PlayerGroup from "@/pages/player/group";
import PlayerStandings from "@/pages/player/standings";
import PlayerStatistics from "@/pages/player/statistics";

// App Routes Component that uses authentication
function AppRoutes() {
  const { user } = useAuth();
  
  return (
    <Switch>
      {/* Authentication page */}
      <Route path="/auth" component={AuthPage} />
      
      {/* Admin routes */}
      <ProtectedRoute 
        path="/" 
        component={() => user?.isAdmin ? <AdminDashboard /> : <PlayerDashboard />} 
      />
      <ProtectedRoute 
        path="/admin/players" 
        component={() => user?.isAdmin ? <AdminPlayers /> : <NotFound />} 
      />
      <ProtectedRoute 
        path="/admin/groups" 
        component={() => user?.isAdmin ? <AdminGroups /> : <NotFound />} 
      />
      <ProtectedRoute 
        path="/admin/matches" 
        component={() => user?.isAdmin ? <AdminMatches /> : <NotFound />} 
      />
      <ProtectedRoute 
        path="/admin/standings" 
        component={() => user?.isAdmin ? <AdminStandings /> : <NotFound />} 
      />
      <ProtectedRoute 
        path="/admin/statistics" 
        component={() => user?.isAdmin ? <AdminStatistics /> : <NotFound />} 
      />
      
      {/* Player routes */}
      <ProtectedRoute 
        path="/player/matches" 
        component={() => !user?.isAdmin ? <PlayerMatches /> : <NotFound />} 
      />
      <ProtectedRoute 
        path="/player/group" 
        component={() => !user?.isAdmin ? <PlayerGroup /> : <NotFound />} 
      />
      <ProtectedRoute 
        path="/player/standings" 
        component={() => !user?.isAdmin ? <PlayerStandings /> : <NotFound />} 
      />
      <ProtectedRoute 
        path="/player/statistics" 
        component={() => !user?.isAdmin ? <PlayerStatistics /> : <NotFound />} 
      />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

// Wrapper component with all providers
function AppWithProviders() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider attribute="class" defaultTheme="light">
        <AuthProvider>
          <TooltipProvider>
            <AppRoutes />
          </TooltipProvider>
          <Toaster />
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

// Main App Component - doesn't use any hooks directly
function App() {
  return <AppWithProviders />;
}

export default App;
