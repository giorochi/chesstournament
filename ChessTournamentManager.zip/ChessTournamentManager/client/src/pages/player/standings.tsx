import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import Layout from "@/components/layout/layout";
import { getUserInitials } from "@/lib/utils";
import TournamentBracket from "@/components/tournament-bracket";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Trophy, Medal, BarChart3 } from "lucide-react";

export default function PlayerStandings() {
  const { user } = useAuth();
  
  // Get active tournament
  const { data: activeTournament, isLoading: tournamentLoading } = useQuery({
    queryKey: ["/api/tournaments/active"],
  });

  // Get tournament groups
  const { data: groups = [], isLoading: groupsLoading } = useQuery({
    queryKey: [`/api/tournaments/${activeTournament?.id}/groups`],
    enabled: !!activeTournament?.id,
  });

  // Get player's group for active tournament
  const { data: playerGroup, isLoading: playerGroupLoading } = useQuery({
    queryKey: [`/api/players/${user?.id}/group`, { tournamentId: activeTournament?.id }],
    enabled: !!user?.id && !!activeTournament?.id,
  });

  // Get tournament standings
  const { data: tournamentStandings = [], isLoading: standingsLoading } = useQuery({
    queryKey: [`/api/tournaments/${activeTournament?.id}/standings`],
    enabled: !!activeTournament?.id,
  });

  // Get matches for the tournament
  const { data: matches = [] } = useQuery({
    queryKey: [`/api/tournaments/${activeTournament?.id}/matches`],
    enabled: !!activeTournament?.id,
  });

  // Filter final stage matches for tournament bracket
  const finalMatches = matches.filter((match: any) => match.isFinalStage);
  
  // Group options for select dropdown
  const groupOptions = groups.map((group: any) => ({
    value: group.id.toString(),
    label: group.name,
  }));

  // Find the user's standing
  const userStanding = tournamentStandings.find((standing: any) => standing.playerId === user?.id);

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
          <div>
            <h1 className="text-2xl font-bold text-[#5D4037]">Tournament Standings</h1>
            <p className="text-gray-500">
              Current rankings for {activeTournament?.name || 'the tournament'}
            </p>
          </div>
        </div>

        {!activeTournament ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500">No active tournament. Please contact the administrator.</p>
            </CardContent>
          </Card>
        ) : (
          <Tabs defaultValue="standings" className="space-y-4">
            <TabsList>
              <TabsTrigger value="standings">Standings</TabsTrigger>
              <TabsTrigger value="bracket">Final Stages Bracket</TabsTrigger>
            </TabsList>
            
            <TabsContent value="standings" className="space-y-4">
              {userStanding && (
                <Card className="bg-[#F5F5DC] border-2 border-[#5D4037]">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-12 h-12 rounded-full bg-[#5D4037] flex items-center justify-center text-white text-lg">
                          {getUserInitials(user?.fullName || "")}
                        </div>
                        <div>
                          <h3 className="font-medium text-lg">Your current standing</h3>
                          <p className="text-gray-600">
                            Rank <span className="font-bold">{userStanding.rank}</span> with <span className="font-bold">{userStanding.points}</span> points
                          </p>
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="text-xs text-gray-500">Your record</div>
                        <div className="text-lg font-bold">
                          {userStanding.wins}W - {userStanding.draws}D - {userStanding.losses}L
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
              
              <Card>
                <CardHeader className="bg-[#5D4037] text-[#F5F5DC]">
                  <CardTitle className="flex items-center">
                    <Trophy className="h-5 w-5 mr-2" />
                    Tournament Standings
                  </CardTitle>
                </CardHeader>
                
                <CardContent className="p-0">
                  {standingsLoading ? (
                    <div className="p-8 text-center">Loading standings...</div>
                  ) : tournamentStandings.length === 0 ? (
                    <div className="p-8 text-center text-gray-500">
                      No standings available. Matches may not have been played yet.
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader className="bg-gray-100">
                          <TableRow>
                            <TableHead className="w-12 text-center">Rank</TableHead>
                            <TableHead>Player</TableHead>
                            <TableHead className="text-center">Played</TableHead>
                            <TableHead className="text-center">W</TableHead>
                            <TableHead className="text-center">D</TableHead>
                            <TableHead className="text-center">L</TableHead>
                            <TableHead className="text-center">Points</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {tournamentStandings.map((standing: any, index: number) => (
                            <TableRow 
                              key={standing.playerId} 
                              className={standing.playerId === user?.id ? "bg-[#F5F5DC] bg-opacity-50" : "hover:bg-gray-50"}
                            >
                              <TableCell className="text-center">
                                {index < 3 ? (
                                  <div className="flex justify-center">
                                    {index === 0 ? (
                                      <Trophy className="h-5 w-5 text-[#FFD700]" />
                                    ) : index === 1 ? (
                                      <Medal className="h-5 w-5 text-[#C0C0C0]" />
                                    ) : (
                                      <Medal className="h-5 w-5 text-[#CD7F32]" />
                                    )}
                                  </div>
                                ) : (
                                  standing.rank
                                )}
                              </TableCell>
                              <TableCell>
                                <div className="flex items-center space-x-3">
                                  <div className="w-10 h-10 rounded-full bg-[#8B6B61] flex items-center justify-center text-white text-xs">
                                    {getUserInitials(standing.playerName)}
                                  </div>
                                  <div>
                                    <div className="font-medium">{standing.playerName}</div>
                                    {standing.playerId === user?.id && (
                                      <div className="text-xs text-gray-500">You</div>
                                    )}
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell className="text-center">{standing.played}</TableCell>
                              <TableCell className="text-center">{standing.wins}</TableCell>
                              <TableCell className="text-center">{standing.draws}</TableCell>
                              <TableCell className="text-center">{standing.losses}</TableCell>
                              <TableCell className="text-center">
                                <span className="px-3 py-1 inline-flex text-sm leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                  {standing.points}
                                </span>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </CardContent>
              </Card>
              
              <div className="text-sm text-gray-600 mt-2">
                Top 2 players from each group qualify for the final stages.
              </div>
            </TabsContent>
            
            <TabsContent value="bracket">
              {finalMatches.length > 0 ? (
                <TournamentBracket 
                  tournamentId={activeTournament.id} 
                  finalMatches={finalMatches}
                  groupOptions={groupOptions}
                />
              ) : (
                <Card>
                  <CardContent className="p-8 text-center">
                    <p className="text-gray-500">Final stage matches have not been created yet.</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        )}
      </div>
    </Layout>
  );
}
