import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import Layout from "@/components/layout/layout";
import MatchCard from "@/components/match-card";
import PlayerStats from "@/components/player-stats";
import GroupStandingTable from "@/components/group-standing-table";

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

export default function PlayerDashboard() {
  const { user } = useAuth();
  
  // Get active tournament
  const { data: activeTournament, isLoading: tournamentLoading } = useQuery({
    queryKey: ["/api/tournaments/active"],
  });

  // Get player's matches for active tournament
  const { data: playerMatches = [], isLoading: matchesLoading } = useQuery({
    queryKey: [`/api/players/${user?.id}/matches`, { tournamentId: activeTournament?.id }],
    enabled: !!user?.id && !!activeTournament?.id,
  });

  // Get player's group for active tournament
  const { data: playerGroup, isLoading: groupLoading } = useQuery({
    queryKey: [`/api/players/${user?.id}/group`, { tournamentId: activeTournament?.id }],
    enabled: !!user?.id && !!activeTournament?.id,
  });

  // Find the next match (not completed and has a date)
  const nextMatch = playerMatches
    .filter((match: any) => !match.completed)
    .sort((a: any, b: any) => {
      if (!a.matchDate) return 1;
      if (!b.matchDate) return -1;
      return new Date(a.matchDate).getTime() - new Date(b.matchDate).getTime();
    })[0];

  // Filter recent matches (completed)
  const recentMatches = playerMatches
    .filter((match: any) => match.completed)
    .sort((a: any, b: any) => {
      if (!a.matchDate) return 1;
      if (!b.matchDate) return -1;
      return new Date(b.matchDate).getTime() - new Date(a.matchDate).getTime();
    })
    .slice(0, 3);

  return (
    <Layout>
      <div className="space-y-6">
        {!activeTournament ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500">No active tournament. Please contact the administrator.</p>
            </CardContent>
          </Card>
        ) : (
          <>
            {/* Player Stats Card */}
            <PlayerStats tournamentId={activeTournament.id} />

            {/* Next Match Card */}
            <Card className="overflow-hidden">
              <CardHeader className="bg-[#8B6B61] p-4 text-white">
                <CardTitle className="font-bold">Your Next Match</CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                {matchesLoading ? (
                  <div className="text-center py-4">Loading your next match...</div>
                ) : !nextMatch ? (
                  <div className="text-center py-4 text-gray-500">
                    You don't have any upcoming matches scheduled.
                  </div>
                ) : (
                  <MatchCard match={nextMatch} isNextMatch={true} />
                )}
              </CardContent>
            </Card>

            {/* Recent Matches & Group Standing */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Recent Matches */}
              <Card className="overflow-hidden">
                <CardHeader className="bg-[#8B6B61] p-4 text-white flex justify-between items-center">
                  <CardTitle className="font-bold">Your Recent Matches</CardTitle>
                </CardHeader>
                <CardContent className="divide-y p-0">
                  {matchesLoading ? (
                    <div className="p-8 text-center">Loading your match history...</div>
                  ) : recentMatches.length === 0 ? (
                    <div className="p-8 text-center text-gray-500">
                      You haven't played any matches yet.
                    </div>
                  ) : (
                    recentMatches.map((match: any) => (
                      <div key={match.id} className="p-4 hover:bg-gray-50">
                        <MatchCard match={match} />
                      </div>
                    ))
                  )}
                </CardContent>
              </Card>

              {/* Group Standing */}
              {playerGroup && (
                <GroupStandingTable 
                  groupId={playerGroup.id} 
                  groupName={playerGroup.name} 
                />
              )}
            </div>
          </>
        )}
      </div>
    </Layout>
  );
}
