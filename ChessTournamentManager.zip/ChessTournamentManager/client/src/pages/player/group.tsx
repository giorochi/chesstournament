import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import Layout from "@/components/layout/layout";
import { getUserInitials } from "@/lib/utils";
import GroupStandingTable from "@/components/group-standing-table";

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Users, FolderKanban, TrophyIcon } from "lucide-react";

export default function PlayerGroup() {
  const { user } = useAuth();
  
  // Get active tournament
  const { data: activeTournament, isLoading: tournamentLoading } = useQuery({
    queryKey: ["/api/tournaments/active"],
  });

  // Get player's group for active tournament
  const { data: playerGroup, isLoading: groupLoading } = useQuery({
    queryKey: [`/api/players/${user?.id}/group`, { tournamentId: activeTournament?.id }],
    enabled: !!user?.id && !!activeTournament?.id,
  });

  // Get group players
  const { data: groupPlayers = [], isLoading: playersLoading } = useQuery({
    queryKey: [`/api/groups/${playerGroup?.id}/players`],
    enabled: !!playerGroup?.id,
  });

  // Get group standings
  const { data: groupStandings = [], isLoading: standingsLoading } = useQuery({
    queryKey: [`/api/groups/${playerGroup?.id}/standings`],
    enabled: !!playerGroup?.id,
  });

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
          <div>
            <h1 className="text-2xl font-bold text-[#5D4037]">My Group</h1>
            <p className="text-gray-500">
              Your group details in {activeTournament?.name || 'the tournament'}
            </p>
          </div>
        </div>

        {!activeTournament ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500">No active tournament. Please contact the administrator.</p>
            </CardContent>
          </Card>
        ) : groupLoading ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500">Loading your group information...</p>
            </CardContent>
          </Card>
        ) : !playerGroup ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500">You haven't been assigned to a group yet.</p>
            </CardContent>
          </Card>
        ) : (
          <Tabs defaultValue="standings" className="space-y-4">
            <TabsList>
              <TabsTrigger value="standings">Group Standings</TabsTrigger>
              <TabsTrigger value="players">Group Players</TabsTrigger>
            </TabsList>
            
            <TabsContent value="standings">
              <GroupStandingTable 
                groupId={playerGroup.id} 
                groupName={playerGroup.name} 
              />
              
              <div className="mt-4">
                <Card>
                  <CardHeader className="bg-[#5D4037] text-[#F5F5DC]">
                    <CardTitle className="flex items-center">
                      <TrophyIcon className="h-5 w-5 mr-2" />
                      Qualification Rules
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    <p className="text-sm text-gray-700">
                      The top 2 players from each group will advance to the quarter-finals stage. 
                      Points are awarded as follows:
                    </p>
                    <ul className="list-disc pl-5 mt-2 text-sm text-gray-700 space-y-1">
                      <li>Win: 1 point</li>
                      <li>Draw: 0.5 points</li>
                      <li>Loss: 0 points</li>
                    </ul>
                    <p className="mt-2 text-sm text-gray-700">
                      In case of a tie in points, rankings will be determined by head-to-head results, 
                      followed by the number of wins.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="players">
              <Card>
                <CardHeader className="bg-[#5D4037] text-[#F5F5DC]">
                  <CardTitle className="flex items-center">
                    <Users className="h-5 w-5 mr-2" />
                    Players in {playerGroup.name}
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  {playersLoading ? (
                    <div className="p-8 text-center">Loading group players...</div>
                  ) : groupPlayers.length === 0 ? (
                    <div className="p-8 text-center text-gray-500">
                      No players assigned to this group yet.
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader className="bg-gray-100">
                          <TableRow>
                            <TableHead>Player</TableHead>
                            <TableHead>Status</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {groupPlayers.map((player: any) => (
                            <TableRow 
                              key={player.id} 
                              className={player.id === user?.id ? "bg-[#F5F5DC] bg-opacity-50" : "hover:bg-gray-50"}
                            >
                              <TableCell>
                                <div className="flex items-center space-x-3">
                                  <div className="w-10 h-10 rounded-full bg-[#8B6B61] flex items-center justify-center text-white">
                                    {getUserInitials(player.fullName)}
                                  </div>
                                  <div>
                                    <div className="font-medium">{player.fullName}</div>
                                    {player.id === user?.id && (
                                      <div className="text-xs text-gray-500">You</div>
                                    )}
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell>
                                {player.id === user?.id ? (
                                  <Badge className="bg-[#1976D2]">You</Badge>
                                ) : (
                                  <Badge variant="outline">Opponent</Badge>
                                )}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </CardContent>
              </Card>
              
              <div className="mt-4">
                <Card>
                  <CardHeader className="bg-[#5D4037] text-[#F5F5DC]">
                    <CardTitle className="flex items-center">
                      <FolderKanban className="h-5 w-5 mr-2" />
                      Group Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    <div className="space-y-4">
                      <div>
                        <h3 className="text-sm font-medium text-gray-700">Group Name</h3>
                        <p className="text-lg">{playerGroup.name}</p>
                      </div>
                      
                      {playerGroup.description && (
                        <div>
                          <h3 className="text-sm font-medium text-gray-700">Description</h3>
                          <p>{playerGroup.description}</p>
                        </div>
                      )}
                      
                      <div>
                        <h3 className="text-sm font-medium text-gray-700">Total Players</h3>
                        <p className="text-lg">{groupPlayers.length}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        )}
      </div>
    </Layout>
  );
}
