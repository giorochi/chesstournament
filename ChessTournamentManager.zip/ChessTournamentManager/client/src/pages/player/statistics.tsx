import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import Layout from "@/components/layout/layout";
import PlayerStats from "@/components/player-stats";
import { calculateWinPercentage } from "@/lib/utils";

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
} from "recharts";
import { PieChart as PieChartIcon, BarChart2, TrendingUp } from "lucide-react";

export default function PlayerStatistics() {
  const { user } = useAuth();
  
  // Get active tournament
  const { data: activeTournament, isLoading: tournamentLoading } = useQuery({
    queryKey: ["/api/tournaments/active"],
  });

  // Get player statistics
  const { data: playerStats, isLoading: statsLoading } = useQuery({
    queryKey: [`/api/players/${user?.id}/statistics`, { tournamentId: activeTournament?.id }],
    enabled: !!user?.id && !!activeTournament?.id,
  });

  // Get player's matches for active tournament
  const { data: playerMatches = [], isLoading: matchesLoading } = useQuery({
    queryKey: [`/api/players/${user?.id}/matches`, { tournamentId: activeTournament?.id }],
    enabled: !!user?.id && !!activeTournament?.id,
  });

  // Prepare data for results pie chart
  const resultDistribution = playerStats ? [
    { name: 'Wins', value: playerStats.wins, fill: '#4CAF50' },
    { name: 'Draws', value: playerStats.draws, fill: '#FFC107' },
    { name: 'Losses', value: playerStats.losses, fill: '#F44336' },
  ] : [];

  // Performance over time
  // We'll simulate a performance chart based on completed matches
  const completedMatches = playerMatches
    .filter((match: any) => match.completed)
    .sort((a: any, b: any) => {
      if (!a.matchDate) return 1;
      if (!b.matchDate) return -1;
      return new Date(a.matchDate).getTime() - new Date(b.matchDate).getTime();
    });

  const performanceData = [];
  let cumulativePoints = 0;
  
  for (let i = 0; i < completedMatches.length; i++) {
    const match = completedMatches[i];
    const isPlayer1 = match.player1Id === user?.id;
    
    let matchPoints = 0;
    if (isPlayer1) {
      matchPoints = match.player1Score === "1" ? 1 : match.player1Score === "0.5" ? 0.5 : 0;
    } else {
      matchPoints = match.player2Score === "1" ? 1 : match.player2Score === "0.5" ? 0.5 : 0;
    }
    
    cumulativePoints += matchPoints;
    
    performanceData.push({
      match: i + 1,
      points: cumulativePoints,
      opponent: isPlayer1 ? match.player2?.fullName?.split(' ')[0] : match.player1?.fullName?.split(' ')[0],
    });
  }

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
          <div>
            <h1 className="text-2xl font-bold text-[#5D4037]">My Statistics</h1>
            <p className="text-gray-500">
              Your performance in {activeTournament?.name || 'the tournament'}
            </p>
          </div>
        </div>

        {!activeTournament ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500">No active tournament. Please contact the administrator.</p>
            </CardContent>
          </Card>
        ) : statsLoading ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500">Loading your statistics...</p>
            </CardContent>
          </Card>
        ) : !playerStats ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500">No statistics available yet. You may not have played any matches.</p>
            </CardContent>
          </Card>
        ) : (
          <>
            {/* Player Stats Card */}
            <PlayerStats tournamentId={activeTournament.id} />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Results Breakdown Pie Chart */}
              {playerStats.played > 0 && (
                <Card>
                  <CardHeader className="bg-[#5D4037] text-[#F5F5DC]">
                    <CardTitle className="flex items-center">
                      <PieChartIcon className="h-5 w-5 mr-2" />
                      Results Breakdown
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-6">
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={resultDistribution}
                          cx="50%"
                          cy="50%"
                          outerRadius={100}
                          dataKey="value"
                          labelLine={false}
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        >
                          {resultDistribution.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.fill} />
                          ))}
                        </Pie>
                        <Tooltip />
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              )}
              
              {/* Win Percentage Bar Chart */}
              {playerStats.played > 0 && (
                <Card>
                  <CardHeader className="bg-[#5D4037] text-[#F5F5DC]">
                    <CardTitle className="flex items-center">
                      <BarChart2 className="h-5 w-5 mr-2" />
                      Win Percentage
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-6">
                    <div className="h-[300px] flex flex-col justify-center">
                      <div className="mb-4 text-center">
                        <span className="text-4xl font-bold">
                          {calculateWinPercentage(playerStats.wins, playerStats.played)}%
                        </span>
                        <p className="text-gray-500 mt-1">Win rate</p>
                      </div>
                      
                      <div className="w-full bg-gray-200 rounded-full h-5">
                        <div 
                          className="bg-[#4CAF50] h-5 rounded-full" 
                          style={{ width: `${calculateWinPercentage(playerStats.wins, playerStats.played)}%` }}
                        ></div>
                      </div>
                      
                      <div className="flex justify-between mt-4 text-sm text-gray-500">
                        <div>0%</div>
                        <div>50%</div>
                        <div>100%</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
            
            {/* Performance Over Time */}
            {performanceData.length > 1 && (
              <Card>
                <CardHeader className="bg-[#5D4037] text-[#F5F5DC]">
                  <CardTitle className="flex items-center">
                    <TrendingUp className="h-5 w-5 mr-2" />
                    Performance Over Time
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={performanceData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="match" label={{ value: 'Match', position: 'insideBottom', offset: -5 }} />
                      <YAxis label={{ value: 'Cumulative Points', angle: -90, position: 'insideLeft' }} />
                      <Tooltip 
                        formatter={(value: any, name: any, props: any) => {
                          const { payload } = props;
                          return [`${value} points (vs ${payload.opponent})`];
                        }}
                      />
                      <Legend />
                      <Bar dataKey="points" name="Cumulative Points" fill="#1976D2" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            )}
          </>
        )}
      </div>
    </Layout>
  );
}
