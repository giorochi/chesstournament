import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import Layout from "@/components/layout/layout";
import MatchCard from "@/components/match-card";

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Calendar, CheckCircle, Clock } from "lucide-react";

export default function PlayerMatches() {
  const { user } = useAuth();
  
  // Get active tournament
  const { data: activeTournament, isLoading: tournamentLoading } = useQuery({
    queryKey: ["/api/tournaments/active"],
  });

  // Get player's matches for active tournament
  const { data: playerMatches = [], isLoading: matchesLoading } = useQuery({
    queryKey: [`/api/players/${user?.id}/matches`, { tournamentId: activeTournament?.id }],
    enabled: !!user?.id && !!activeTournament?.id,
  });

  // Filter upcoming matches (not completed)
  const upcomingMatches = playerMatches
    .filter((match: any) => !match.completed)
    .sort((a: any, b: any) => {
      if (!a.matchDate) return 1;
      if (!b.matchDate) return -1;
      return new Date(a.matchDate).getTime() - new Date(b.matchDate).getTime();
    });

  // Filter completed matches
  const completedMatches = playerMatches
    .filter((match: any) => match.completed)
    .sort((a: any, b: any) => {
      if (!a.matchDate) return 1;
      if (!b.matchDate) return -1;
      return new Date(b.matchDate).getTime() - new Date(a.matchDate).getTime();
    });

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
          <div>
            <h1 className="text-2xl font-bold text-[#5D4037]">My Matches</h1>
            <p className="text-gray-500">
              Your scheduled matches in {activeTournament?.name || 'the tournament'}
            </p>
          </div>
        </div>

        {!activeTournament ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500">No active tournament. Please contact the administrator.</p>
            </CardContent>
          </Card>
        ) : (
          <Tabs defaultValue="upcoming" className="space-y-4">
            <TabsList>
              <TabsTrigger value="upcoming">Upcoming Matches</TabsTrigger>
              <TabsTrigger value="completed">Match History</TabsTrigger>
              <TabsTrigger value="all">All Matches</TabsTrigger>
            </TabsList>
            
            <TabsContent value="upcoming">
              <Card>
                <CardHeader className="bg-[#5D4037] text-[#F5F5DC]">
                  <CardTitle className="flex items-center">
                    <Calendar className="h-5 w-5 mr-2" />
                    Upcoming Matches
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4">
                  {matchesLoading ? (
                    <div className="p-8 text-center">Loading your matches...</div>
                  ) : upcomingMatches.length === 0 ? (
                    <div className="p-8 text-center text-gray-500">
                      You don't have any upcoming matches scheduled.
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {upcomingMatches.map((match: any) => (
                        <div key={match.id} className="relative">
                          <MatchCard match={match} />
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="completed">
              <Card>
                <CardHeader className="bg-[#5D4037] text-[#F5F5DC]">
                  <CardTitle className="flex items-center">
                    <CheckCircle className="h-5 w-5 mr-2" />
                    Match History
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4">
                  {matchesLoading ? (
                    <div className="p-8 text-center">Loading your match history...</div>
                  ) : completedMatches.length === 0 ? (
                    <div className="p-8 text-center text-gray-500">
                      You haven't played any matches yet.
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {completedMatches.map((match: any) => (
                        <MatchCard key={match.id} match={match} />
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="all">
              <Card>
                <CardHeader className="bg-[#5D4037] text-[#F5F5DC]">
                  <CardTitle className="flex items-center">
                    <Calendar className="h-5 w-5 mr-2" />
                    All Matches
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4">
                  {matchesLoading ? (
                    <div className="p-8 text-center">Loading your matches...</div>
                  ) : playerMatches.length === 0 ? (
                    <div className="p-8 text-center text-gray-500">
                      You don't have any matches in this tournament.
                    </div>
                  ) : (
                    <>
                      {upcomingMatches.length > 0 && (
                        <div className="mb-6">
                          <h3 className="flex items-center text-lg font-semibold text-[#5D4037] mb-3">
                            <Clock className="h-5 w-5 mr-2 text-[#1976D2]" />
                            Upcoming Matches
                          </h3>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {upcomingMatches.map((match: any) => (
                              <MatchCard key={match.id} match={match} />
                            ))}
                          </div>
                        </div>
                      )}
                      
                      {completedMatches.length > 0 && (
                        <div>
                          <h3 className="flex items-center text-lg font-semibold text-[#5D4037] mb-3">
                            <CheckCircle className="h-5 w-5 mr-2 text-[#4CAF50]" />
                            Completed Matches
                          </h3>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {completedMatches.map((match: any) => (
                              <MatchCard key={match.id} match={match} />
                            ))}
                          </div>
                        </div>
                      )}
                    </>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        )}
      </div>
    </Layout>
  );
}
