import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import Layout from "@/components/layout/layout";
import { getUserInitials } from "@/lib/utils";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { FolderPlus, Users, UserPlus } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Form schema for creating a group
const createGroupSchema = z.object({
  name: z.string().min(2, "Group name is required"),
  description: z.string().optional(),
  tournamentId: z.number(),
});

// Form schema for assigning player to group
const assignPlayerSchema = z.object({
  playerId: z.string().min(1, "Player is required"),
  groupId: z.string().min(1, "Group is required"),
});

type CreateGroupFormValues = z.infer<typeof createGroupSchema>;
type AssignPlayerFormValues = z.infer<typeof assignPlayerSchema>;

export default function AdminGroups() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [isCreateGroupOpen, setIsCreateGroupOpen] = useState(false);
  const [isAssignPlayerOpen, setIsAssignPlayerOpen] = useState(false);
  const [selectedGroup, setSelectedGroup] = useState<string | null>(null);
  
  // Get active tournament
  const { data: activeTournament } = useQuery({
    queryKey: ["/api/tournaments/active"],
  });

  // Get groups for active tournament
  const { data: groups = [], isLoading: groupsLoading } = useQuery({
    queryKey: [`/api/tournaments/${activeTournament?.id}/groups`],
    enabled: !!activeTournament?.id,
  });

  // Get all players
  const { data: players = [], isLoading: playersLoading } = useQuery({
    queryKey: ["/api/players"],
  });

  // Get players for selected group
  const { data: groupPlayers = [], isLoading: groupPlayersLoading } = useQuery({
    queryKey: [`/api/groups/${selectedGroup}/players`],
    enabled: !!selectedGroup,
  });

  // Group creation form
  const createGroupForm = useForm<CreateGroupFormValues>({
    resolver: zodResolver(createGroupSchema),
    defaultValues: {
      name: "",
      description: "",
      tournamentId: activeTournament?.id,
    },
  });

  // Player assignment form
  const assignPlayerForm = useForm<AssignPlayerFormValues>({
    resolver: zodResolver(assignPlayerSchema),
    defaultValues: {
      playerId: "",
      groupId: selectedGroup || "",
    },
  });

  // Update tournamentId when active tournament changes
  useQuery({
    queryKey: ["/api/tournaments/active"],
    enabled: !!activeTournament?.id,
    onSuccess: (data) => {
      createGroupForm.setValue("tournamentId", data.id);
    },
  });

  // Update groupId when selected group changes
  useQuery({
    queryKey: [`/api/groups/${selectedGroup}`],
    enabled: !!selectedGroup,
    onSuccess: () => {
      assignPlayerForm.setValue("groupId", selectedGroup || "");
    },
  });

  // Create group mutation
  const createGroupMutation = useMutation({
    mutationFn: async (data: CreateGroupFormValues) => {
      const res = await apiRequest("POST", "/api/groups", data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Group created",
        description: "The group has been created successfully",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/tournaments/${activeTournament?.id}/groups`] });
      createGroupForm.reset();
      setIsCreateGroupOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create group",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Assign player mutation
  const assignPlayerMutation = useMutation({
    mutationFn: async (data: AssignPlayerFormValues) => {
      const res = await apiRequest(
        "POST", 
        `/api/groups/${data.groupId}/players`, 
        { playerId: parseInt(data.playerId) }
      );
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Player assigned",
        description: "The player has been assigned to the group successfully",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/groups/${selectedGroup}/players`] });
      assignPlayerForm.reset();
      setIsAssignPlayerOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to assign player",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Filter out players already in the selected group
  const availablePlayers = players.filter((player: any) => 
    !groupPlayers.find((groupPlayer: any) => groupPlayer.id === player.id)
  );

  // Submit handlers
  const onCreateGroupSubmit = (data: CreateGroupFormValues) => {
    createGroupMutation.mutate(data);
  };

  const onAssignPlayerSubmit = (data: AssignPlayerFormValues) => {
    assignPlayerMutation.mutate(data);
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
          <div>
            <h1 className="text-2xl font-bold text-[#5D4037]">Groups Management</h1>
            <p className="text-gray-500">
              {groups.length || 0} groups in the {activeTournament?.name || 'tournament'}
            </p>
          </div>
          
          <Button
            className="bg-[#1976D2] hover:bg-[#004BA0]"
            onClick={() => setIsCreateGroupOpen(true)}
            disabled={!activeTournament}
          >
            <FolderPlus className="h-4 w-4 mr-2" />
            Create New Group
          </Button>
        </div>

        {!activeTournament ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500">No active tournament. Please activate a tournament first.</p>
            </CardContent>
          </Card>
        ) : (
          <Tabs defaultValue="groups" className="space-y-4">
            <TabsList>
              <TabsTrigger value="groups">Groups</TabsTrigger>
              <TabsTrigger value="players" disabled={!selectedGroup}>
                Group Players
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="groups" className="space-y-4">
              <Card>
                <CardHeader className="bg-[#5D4037] text-[#F5F5DC]">
                  <CardTitle className="flex items-center">
                    <Users className="h-5 w-5 mr-2" />
                    Tournament Groups
                  </CardTitle>
                </CardHeader>
                
                <CardContent className="p-0">
                  {groupsLoading ? (
                    <div className="p-8 text-center">Loading groups...</div>
                  ) : (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader className="bg-gray-100">
                          <TableRow>
                            <TableHead>Name</TableHead>
                            <TableHead>Description</TableHead>
                            <TableHead>Players</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {groups.length > 0 ? (
                            groups.map((group: any) => (
                              <TableRow key={group.id} className="hover:bg-gray-50">
                                <TableCell className="font-medium">{group.name}</TableCell>
                                <TableCell>{group.description || "-"}</TableCell>
                                <TableCell>
                                  <Badge variant="outline" className="bg-[#F5F5DC]">
                                    <Users className="h-3 w-3 mr-1" />
                                    {/* This would ideally show the count of players in the group */}
                                    0 Players
                                  </Badge>
                                </TableCell>
                                <TableCell className="text-right">
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => {
                                      setSelectedGroup(group.id.toString());
                                      assignPlayerForm.setValue("groupId", group.id.toString());
                                    }}
                                  >
                                    View Players
                                  </Button>
                                </TableCell>
                              </TableRow>
                            ))
                          ) : (
                            <TableRow>
                              <TableCell colSpan={4} className="text-center py-8 text-gray-500">
                                No groups created yet for this tournament
                              </TableCell>
                            </TableRow>
                          )}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="players" className="space-y-4">
              {selectedGroup && (
                <>
                  <div className="flex justify-between items-center">
                    <h2 className="text-xl font-semibold text-[#5D4037]">
                      Players in {groups.find((g: any) => g.id.toString() === selectedGroup)?.name}
                    </h2>
                    <Button
                      onClick={() => setIsAssignPlayerOpen(true)}
                      className="bg-[#1976D2] hover:bg-[#004BA0]"
                    >
                      <UserPlus className="h-4 w-4 mr-2" />
                      Assign Player
                    </Button>
                  </div>
                  
                  <Card>
                    <CardContent className="p-0">
                      {groupPlayersLoading ? (
                        <div className="p-8 text-center">Loading group players...</div>
                      ) : (
                        <div className="overflow-x-auto">
                          <Table>
                            <TableHeader className="bg-gray-100">
                              <TableRow>
                                <TableHead>Name</TableHead>
                                <TableHead>Credential Code</TableHead>
                                <TableHead>Username</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {groupPlayers.length > 0 ? (
                                groupPlayers.map((player: any) => (
                                  <TableRow key={player.id} className="hover:bg-gray-50">
                                    <TableCell>
                                      <div className="flex items-center space-x-3">
                                        <div className="w-10 h-10 rounded-full bg-[#8B6B61] flex items-center justify-center text-white">
                                          {getUserInitials(player.fullName)}
                                        </div>
                                        <div className="font-medium">{player.fullName}</div>
                                      </div>
                                    </TableCell>
                                    <TableCell>
                                      <Badge variant="outline" className="font-mono">
                                        {player.credentialCode}
                                      </Badge>
                                    </TableCell>
                                    <TableCell>{player.username}</TableCell>
                                  </TableRow>
                                ))
                              ) : (
                                <TableRow>
                                  <TableCell colSpan={3} className="text-center py-8 text-gray-500">
                                    No players assigned to this group yet
                                  </TableCell>
                                </TableRow>
                              )}
                            </TableBody>
                          </Table>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </>
              )}
            </TabsContent>
          </Tabs>
        )}
      </div>

      {/* Create Group Dialog */}
      <Dialog open={isCreateGroupOpen} onOpenChange={setIsCreateGroupOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Create New Group</DialogTitle>
            <DialogDescription>
              Create a new group for the tournament. Groups are used to organize players.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...createGroupForm}>
            <form onSubmit={createGroupForm.handleSubmit(onCreateGroupSubmit)} className="space-y-4">
              <FormField
                control={createGroupForm.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Group Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter group name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={createGroupForm.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter group description" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsCreateGroupOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="bg-[#1976D2] hover:bg-[#004BA0]"
                  disabled={createGroupMutation.isPending}
                >
                  {createGroupMutation.isPending ? "Creating..." : "Create Group"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Assign Player Dialog */}
      <Dialog open={isAssignPlayerOpen} onOpenChange={setIsAssignPlayerOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Assign Player to Group</DialogTitle>
            <DialogDescription>
              Select a player to add to the group "{groups.find((g: any) => g.id.toString() === selectedGroup)?.name}".
            </DialogDescription>
          </DialogHeader>
          
          <Form {...assignPlayerForm}>
            <form onSubmit={assignPlayerForm.handleSubmit(onAssignPlayerSubmit)} className="space-y-4">
              <FormField
                control={assignPlayerForm.control}
                name="playerId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Player</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a player" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {availablePlayers.map((player: any) => (
                          <SelectItem key={player.id} value={player.id.toString()}>
                            {player.fullName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsAssignPlayerOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="bg-[#1976D2] hover:bg-[#004BA0]"
                  disabled={assignPlayerMutation.isPending || availablePlayers.length === 0}
                >
                  {assignPlayerMutation.isPending ? "Assigning..." : "Assign Player"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
