import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Layout from "@/components/layout/layout";
import ActivityLog from "@/components/activity-log";
import TournamentBracket from "@/components/tournament-bracket";
import MatchCard from "@/components/match-card";
import PlayerForm from "@/components/player-form";
import PairingGenerator from "@/components/pairing-generator";
import TournamentForm from "@/components/tournament-form";
import TournamentsList from "@/components/tournaments-list";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  BarChart3,
  UserPlus,
  Calendar,
  LayoutDashboard,
  Users,
  CalendarClock,
  Trophy,
  AlertTriangle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function AdminDashboard() {
  const [isPlayerFormOpen, setIsPlayerFormOpen] = useState(false);
  const [isPairingFormOpen, setIsPairingFormOpen] = useState(false);
  const [isTournamentFormOpen, setIsTournamentFormOpen] = useState(false);
  
  // Get active tournament
  const { data: activeTournament, isLoading: tournamentLoading } = useQuery({
    queryKey: ["/api/tournaments/active"],
  });

  // Get tournament statistics (players, groups, matches)
  const { data: players } = useQuery({
    queryKey: ["/api/players"],
    enabled: !!activeTournament,
  });

  const { data: groups } = useQuery({
    queryKey: [`/api/tournaments/${activeTournament?.id}/groups`],
    enabled: !!activeTournament,
  });

  const { data: matches } = useQuery({
    queryKey: [`/api/tournaments/${activeTournament?.id}/matches`],
    enabled: !!activeTournament,
  });

  // Get upcoming matches
  const upcomingMatches = matches?.filter(
    (match: any) => !match.completed && match.matchDate
  ).sort((a: any, b: any) => 
    new Date(a.matchDate).getTime() - new Date(b.matchDate).getTime()
  ).slice(0, 3);

  // Group options for bracket filter
  const groupOptions = groups?.map((group: any) => ({
    value: group.id.toString(),
    label: group.name,
  })) || [];

  // Final stage matches for tournament bracket
  const finalMatches = matches?.filter(
    (match: any) => match.isFinalStage
  ) || [];

  // Tournament progress
  const completedMatches = matches?.filter((match: any) => match.completed) || [];
  const progressPercentage = matches?.length 
    ? Math.round((completedMatches.length / matches.length) * 100) 
    : 0;

  // Current stage info
  const currentStage = "Group Stage";
  const currentRound = groups?.length ? `Round ${Math.ceil(completedMatches.length / groups.length)}` : "";

  return (
    <Layout>
      <div className="space-y-6">
        {/* No Tournament Warning */}
        {!activeTournament && !tournamentLoading && (
          <Alert variant="warning" className="bg-amber-50 border-amber-200">
            <AlertTriangle className="h-4 w-4 text-amber-600" />
            <AlertTitle className="text-amber-800">Nessun torneo attivo</AlertTitle>
            <AlertDescription className="text-amber-700">
              Non ci sono tornei attivi al momento. Crea un nuovo torneo o attiva un torneo esistente per iniziare.
            </AlertDescription>
            <Button 
              className="mt-2 bg-amber-600 hover:bg-amber-700 text-white"
              onClick={() => setIsTournamentFormOpen(true)}
            >
              <Trophy className="h-4 w-4 mr-2" />
              Crea Nuovo Torneo
            </Button>
          </Alert>
        )}

        {/* Tournaments List */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold text-[#5D4037]">Gestione Tornei</h2>
            <Button 
              className="bg-[#1976D2] hover:bg-[#004BA0]"
              onClick={() => setIsTournamentFormOpen(true)}
            >
              <Trophy className="h-4 w-4 mr-2" />
              Crea Nuovo Torneo
            </Button>
          </div>
          <TournamentsList />
        </div>

        {activeTournament && (
          <>
            {/* Tournament Info */}
            <Card className="bg-white shadow-md">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-bold text-[#5D4037]">Torneo: {activeTournament.name}</h2>
                  <Button className="bg-[#1976D2] hover:bg-[#004BA0]">Impostazioni</Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-[#F5F5DC] rounded-lg p-4 flex items-center space-x-3">
                    <div className="bg-[#5D4037] rounded-full p-3 text-[#F5F5DC]">
                      <Users className="h-6 w-6" />
                    </div>
                    <div>
                      <div className="text-sm text-gray-600">Giocatori</div>
                      <div className="text-2xl font-bold">{players?.length || 0}</div>
                    </div>
                  </div>
                  <div className="bg-[#F5F5DC] rounded-lg p-4 flex items-center space-x-3">
                    <div className="bg-[#5D4037] rounded-full p-3 text-[#F5F5DC]">
                      <LayoutDashboard className="h-6 w-6" />
                    </div>
                    <div>
                      <div className="text-sm text-gray-600">Gironi</div>
                      <div className="text-2xl font-bold">{groups?.length || 0}</div>
                    </div>
                  </div>
                  <div className="bg-[#F5F5DC] rounded-lg p-4 flex items-center space-x-3">
                    <div className="bg-[#5D4037] rounded-full p-3 text-[#F5F5DC]">
                      <Calendar className="h-6 w-6" />
                    </div>
                    <div>
                      <div className="text-sm text-gray-600">Partite</div>
                      <div className="text-2xl font-bold">{matches?.length || 0}</div>
                    </div>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t">
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="font-semibold">Progresso Torneo</h3>
                    <span className="text-sm text-gray-500">
                      {currentStage}: {currentRound}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div 
                      className="bg-[#1976D2] h-2.5 rounded-full" 
                      style={{ width: `${progressPercentage}%` }}
                    ></div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Action Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <Card className="overflow-hidden hover:shadow-lg transition-shadow">
                <CardHeader className="bg-[#5D4037] text-[#F5F5DC]">
                  <CardTitle>Registra Nuovo Giocatore</CardTitle>
                </CardHeader>
                <CardContent className="p-4">
                  <CardDescription className="mb-4">
                    Aggiungi un nuovo giocatore al torneo e genera le credenziali
                  </CardDescription>
                  <Button 
                    className="w-full bg-[#1976D2] hover:bg-[#004BA0]"
                    onClick={() => setIsPlayerFormOpen(true)}
                  >
                    <UserPlus className="h-4 w-4 mr-2" />
                    Aggiungi Giocatore
                  </Button>
                </CardContent>
              </Card>
              
              <Card className="overflow-hidden hover:shadow-lg transition-shadow">
                <CardHeader className="bg-[#5D4037] text-[#F5F5DC]">
                  <CardTitle>Genera Accoppiamenti</CardTitle>
                </CardHeader>
                <CardContent className="p-4">
                  <CardDescription className="mb-4">
                    Crea accoppiamenti per il prossimo turno di partite
                  </CardDescription>
                  <Button 
                    className="w-full bg-[#1976D2] hover:bg-[#004BA0]"
                    onClick={() => setIsPairingFormOpen(true)}
                  >
                    <CalendarClock className="h-4 w-4 mr-2" />
                    Crea Accoppiamenti
                  </Button>
                </CardContent>
              </Card>
              
              <Card className="overflow-hidden hover:shadow-lg transition-shadow">
                <CardHeader className="bg-[#5D4037] text-[#F5F5DC]">
                  <CardTitle>Gestione Scacchiere</CardTitle>
                </CardHeader>
                <CardContent className="p-4">
                  <CardDescription className="mb-4">
                    Assegna e gestisci le scacchiere per le partite
                  </CardDescription>
                  <Button className="w-full bg-[#1976D2] hover:bg-[#004BA0]">
                    <BarChart3 className="h-4 w-4 mr-2" />
                    Gestisci Scacchiere
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity & Upcoming Matches */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <ActivityLog tournamentId={activeTournament.id} limit={3} />

              {/* Upcoming Matches */}
              <Card className="overflow-hidden">
                <CardHeader className="bg-[#8B6B61] p-4 text-white flex justify-between items-center">
                  <CardTitle className="font-bold">Prossime Partite</CardTitle>
                  <Button variant="link" className="text-sm text-white hover:text-[#F5F5DC]">
                    Vedi Tutte
                  </Button>
                </CardHeader>
                <CardContent className="divide-y p-0">
                  {upcomingMatches && upcomingMatches.length > 0 ? (
                    upcomingMatches.map((match: any) => (
                      <div key={match.id} className="p-2">
                        <MatchCard match={match} />
                      </div>
                    ))
                  ) : (
                    <div className="p-4 text-center text-gray-500">
                      Nessuna partita programmata
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Tournament Brackets */}
            {finalMatches && finalMatches.length > 0 && (
              <TournamentBracket 
                tournamentId={activeTournament.id} 
                finalMatches={finalMatches} 
                groupOptions={groupOptions} 
              />
            )}
          </>
        )}
      </div>

      {/* Player Registration Form Dialog */}
      <PlayerForm 
        isOpen={isPlayerFormOpen} 
        onClose={() => setIsPlayerFormOpen(false)} 
      />

      {/* Pairing Generator Dialog */}
      <PairingGenerator 
        isOpen={isPairingFormOpen} 
        onClose={() => setIsPairingFormOpen(false)}
        tournamentId={activeTournament?.id}
      />

      {/* Tournament Form Dialog */}
      <TournamentForm 
        isOpen={isTournamentFormOpen} 
        onClose={() => setIsTournamentFormOpen(false)} 
      />
    </Layout>
  );
}
