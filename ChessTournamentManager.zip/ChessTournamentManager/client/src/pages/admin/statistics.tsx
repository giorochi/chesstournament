import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Layout from "@/components/layout/layout";
import { getUserInitials, calculateWinPercentage } from "@/lib/utils";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  BarChart,
  ResponsiveContainer,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Bar,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { LineChart, BarChart2, PieChart as PieChartIcon, Users } from "lucide-react";

export default function AdminStatistics() {
  const [selectedPlayer, setSelectedPlayer] = useState<string>("all");
  
  // Get active tournament
  const { data: activeTournament, isLoading: tournamentLoading } = useQuery({
    queryKey: ["/api/tournaments/active"],
  });

  // Get all players
  const { data: players = [], isLoading: playersLoading } = useQuery({
    queryKey: ["/api/players"],
  });

  // Get tournament standings for stats
  const { data: tournamentStandings = [], isLoading: standingsLoading } = useQuery({
    queryKey: [`/api/tournaments/${activeTournament?.id}/standings`],
    enabled: !!activeTournament?.id,
  });

  // Get player statistics if a player is selected
  const { data: playerStats, isLoading: playerStatsLoading } = useQuery({
    queryKey: [`/api/players/${selectedPlayer}/statistics`, { tournamentId: activeTournament?.id }],
    enabled: !!selectedPlayer && selectedPlayer !== "all" && !!activeTournament?.id,
  });

  // Get matches for the tournament
  const { data: matches = [] } = useQuery({
    queryKey: [`/api/tournaments/${activeTournament?.id}/matches`],
    enabled: !!activeTournament?.id,
  });

  // Calculate top performers
  const topPlayers = [...tournamentStandings]
    .sort((a: any, b: any) => b.points - a.points)
    .slice(0, 5);
    
  // Prepare data for charts
  const pointsData = topPlayers.map((player: any) => ({
    name: player.playerName.split(' ')[0], // Use first name only for cleaner chart
    points: player.points,
  }));
  
  // Win-loss ratio for top players
  const winRatioData = topPlayers.map((player: any) => ({
    name: player.playerName.split(' ')[0],
    winPercentage: calculateWinPercentage(player.wins, player.played),
  }));
  
  // Match result distribution
  const completedMatches = matches.filter((match: any) => match.completed);
  const totalResults = completedMatches.length;
  
  let wins = 0;
  let draws = 0;
  let losses = 0;
  
  completedMatches.forEach((match: any) => {
    if (match.player1Score === match.player2Score) {
      draws++;
    } else {
      wins++;
      losses++;
    }
  });
  
  const resultDistribution = [
    { name: "Wins", value: wins, fill: "#4CAF50" },
    { name: "Draws", value: draws, fill: "#FFC107" },
    { name: "Losses", value: losses, fill: "#F44336" },
  ];

  // Colors for charts
  const CHART_COLORS = [
    "#1976D2", // Primary blue
    "#5D4037", // Primary brown
    "#4CAF50", // Green
    "#FFC107", // Yellow
    "#F44336", // Red
  ];

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
          <div>
            <h1 className="text-2xl font-bold text-[#5D4037]">Tournament Statistics</h1>
            <p className="text-gray-500">
              Performance analytics for {activeTournament?.name || 'the tournament'}
            </p>
          </div>
          
          <Select value={selectedPlayer} onValueChange={setSelectedPlayer}>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Select player to view stats" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tournament Overview</SelectItem>
              {players.map((player: any) => (
                <SelectItem key={player.id} value={player.id.toString()}>
                  {player.fullName}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {!activeTournament ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500">No active tournament. Please activate a tournament first.</p>
            </CardContent>
          </Card>
        ) : selectedPlayer === "all" ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Top Performers */}
            <Card>
              <CardHeader className="bg-[#5D4037] text-[#F5F5DC]">
                <CardTitle className="flex items-center">
                  <Users className="h-5 w-5 mr-2" />
                  Top Performers
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                {standingsLoading ? (
                  <div className="p-4 text-center">Loading statistics...</div>
                ) : topPlayers.length === 0 ? (
                  <div className="p-4 text-center text-gray-500">
                    No player statistics available yet.
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={pointsData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis label={{ value: 'Points', angle: -90, position: 'insideLeft' }} />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="points" name="Total Points" fill="#1976D2" />
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>
            
            {/* Win Percentage */}
            <Card>
              <CardHeader className="bg-[#5D4037] text-[#F5F5DC]">
                <CardTitle className="flex items-center">
                  <BarChart2 className="h-5 w-5 mr-2" />
                  Win Percentage
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                {standingsLoading ? (
                  <div className="p-4 text-center">Loading statistics...</div>
                ) : winRatioData.length === 0 ? (
                  <div className="p-4 text-center text-gray-500">
                    No player statistics available yet.
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={winRatioData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis label={{ value: 'Win %', angle: -90, position: 'insideLeft' }} />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="winPercentage" name="Win Percentage" fill="#4CAF50" />
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>
            
            {/* Match Results Distribution */}
            <Card>
              <CardHeader className="bg-[#5D4037] text-[#F5F5DC]">
                <CardTitle className="flex items-center">
                  <PieChartIcon className="h-5 w-5 mr-2" />
                  Match Results Distribution
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                {matches.length === 0 || completedMatches.length === 0 ? (
                  <div className="p-4 text-center text-gray-500">
                    No completed matches available yet.
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={resultDistribution}
                        cx="50%"
                        cy="50%"
                        outerRadius={100}
                        dataKey="value"
                        labelLine={false}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {resultDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.fill} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>
            
            {/* Tournament Progress */}
            <Card>
              <CardHeader className="bg-[#5D4037] text-[#F5F5DC]">
                <CardTitle className="flex items-center">
                  <LineChart className="h-5 w-5 mr-2" />
                  Tournament Overview
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                  <div className="bg-[#F5F5DC] rounded-lg p-4 text-center">
                    <div className="text-sm text-gray-600 mb-1">Total Players</div>
                    <div className="text-2xl font-bold">{players.length}</div>
                  </div>
                  <div className="bg-[#F5F5DC] rounded-lg p-4 text-center">
                    <div className="text-sm text-gray-600 mb-1">Total Matches</div>
                    <div className="text-2xl font-bold">{matches.length}</div>
                  </div>
                  <div className="bg-[#F5F5DC] rounded-lg p-4 text-center">
                    <div className="text-sm text-gray-600 mb-1">Completed</div>
                    <div className="text-2xl font-bold">{completedMatches.length}</div>
                  </div>
                </div>
                
                <div className="mt-6">
                  <h3 className="text-sm font-medium mb-2">Tournament Progress</h3>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div 
                      className="bg-[#1976D2] h-2.5 rounded-full" 
                      style={{ width: `${matches.length ? (completedMatches.length / matches.length) * 100 : 0}%` }}
                    ></div>
                  </div>
                  <div className="text-right text-sm text-gray-500 mt-1">
                    {completedMatches.length} / {matches.length} matches completed
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        ) : (
          <div className="space-y-6">
            {playerStatsLoading ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <p className="text-gray-500">Loading player statistics...</p>
                </CardContent>
              </Card>
            ) : !playerStats ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <p className="text-gray-500">No statistics available for this player.</p>
                </CardContent>
              </Card>
            ) : (
              <>
                <Card>
                  <CardHeader className="bg-[#5D4037] text-[#F5F5DC]">
                    <div className="flex items-center">
                      <div className="w-10 h-10 rounded-full bg-[#8B6B61] flex items-center justify-center text-white mr-3">
                        {getUserInitials(players.find((p: any) => p.id.toString() === selectedPlayer)?.fullName || "")}
                      </div>
                      <CardTitle>
                        {players.find((p: any) => p.id.toString() === selectedPlayer)?.fullName} - Statistics
                      </CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-6">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                      <div className="bg-[#F5F5DC] rounded-lg p-4 text-center">
                        <div className="text-sm text-gray-600 mb-1">Matches Played</div>
                        <div className="text-2xl font-bold">{playerStats.played}</div>
                      </div>
                      <div className="bg-[#F5F5DC] rounded-lg p-4 text-center">
                        <div className="text-sm text-gray-600 mb-1">Wins</div>
                        <div className="text-2xl font-bold">{playerStats.wins}</div>
                      </div>
                      <div className="bg-[#F5F5DC] rounded-lg p-4 text-center">
                        <div className="text-sm text-gray-600 mb-1">Draws</div>
                        <div className="text-2xl font-bold">{playerStats.draws}</div>
                      </div>
                      <div className="bg-[#F5F5DC] rounded-lg p-4 text-center">
                        <div className="text-sm text-gray-600 mb-1">Points</div>
                        <div className="text-2xl font-bold">{playerStats.points}</div>
                      </div>
                    </div>
                    
                    {playerStats.played > 0 && (
                      <div className="mt-6">
                        <h3 className="text-sm font-medium mb-2">Win Percentage</h3>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div 
                            className="bg-[#4CAF50] h-2.5 rounded-full" 
                            style={{ width: `${calculateWinPercentage(playerStats.wins, playerStats.played)}%` }}
                          ></div>
                        </div>
                        <div className="text-right text-sm text-gray-500 mt-1">
                          {calculateWinPercentage(playerStats.wins, playerStats.played)}%
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
                
                {playerStats.played > 0 && (
                  <Card>
                    <CardHeader className="bg-[#5D4037] text-[#F5F5DC]">
                      <CardTitle className="flex items-center">
                        <PieChartIcon className="h-5 w-5 mr-2" />
                        Results Breakdown
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="pt-6">
                      <ResponsiveContainer width="100%" height={300}>
                        <PieChart>
                          <Pie
                            data={[
                              { name: 'Wins', value: playerStats.wins, fill: '#4CAF50' },
                              { name: 'Draws', value: playerStats.draws, fill: '#FFC107' },
                              { name: 'Losses', value: playerStats.losses, fill: '#F44336' },
                            ]}
                            cx="50%"
                            cy="50%"
                            outerRadius={100}
                            dataKey="value"
                            labelLine={false}
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          />
                          <Tooltip />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                )}
              </>
            )}
          </div>
        )}
      </div>
    </Layout>
  );
}
