import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Layout from "@/components/layout/layout";
import PlayerForm from "@/components/player-form";
import { getUserInitials } from "@/lib/utils";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { UserPlus, Search, MoreHorizontal, Check, Users } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function AdminPlayers() {
  const [isPlayerFormOpen, setIsPlayerFormOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  
  // Get all players
  const { data: players, isLoading } = useQuery({
    queryKey: ["/api/players"],
  });

  // Get active tournament
  const { data: activeTournament } = useQuery({
    queryKey: ["/api/tournaments/active"],
  });

  // Filter players by search term
  const filteredPlayers = players?.filter((player: any) =>
    player.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    player.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
    player.credentialCode.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
          <div>
            <h1 className="text-2xl font-bold text-[#5D4037]">Players Management</h1>
            <p className="text-gray-500">
              {players?.length || 0} players registered in the system
            </p>
          </div>
          
          <Button
            className="bg-[#1976D2] hover:bg-[#004BA0]"
            onClick={() => setIsPlayerFormOpen(true)}
          >
            <UserPlus className="h-4 w-4 mr-2" />
            Register New Player
          </Button>
        </div>

        <Card>
          <CardHeader className="bg-[#5D4037] text-[#F5F5DC]">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-2 sm:space-y-0">
              <CardTitle className="flex items-center">
                <Users className="h-5 w-5 mr-2" />
                Players Directory
              </CardTitle>
              
              <div className="relative w-full sm:w-64">
                <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search players..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8 bg-[#F5F5DC] text-gray-900"
                />
              </div>
            </div>
          </CardHeader>
          
          <CardContent className="p-0">
            {isLoading ? (
              <div className="p-8 text-center">Loading players...</div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader className="bg-gray-100">
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Credential Code</TableHead>
                      <TableHead>Username</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredPlayers && filteredPlayers.length > 0 ? (
                      filteredPlayers.map((player: any) => (
                        <TableRow key={player.id} className="hover:bg-gray-50">
                          <TableCell>
                            <div className="flex items-center space-x-3">
                              <div className="w-10 h-10 rounded-full bg-[#8B6B61] flex items-center justify-center text-white">
                                {getUserInitials(player.fullName)}
                              </div>
                              <div>
                                <div className="font-medium">{player.fullName}</div>
                                <div className="text-xs text-gray-500">ID: #{player.id}</div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className="font-mono">
                              {player.credentialCode}
                            </Badge>
                          </TableCell>
                          <TableCell>{player.username}</TableCell>
                          <TableCell>
                            {player.isAdmin ? (
                              <Badge className="bg-[#5D4037]">Admin</Badge>
                            ) : (
                              <Badge className="bg-[#1976D2]">Player</Badge>
                            )}
                          </TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" className="h-8 w-8 p-0">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem>View Details</DropdownMenuItem>
                                <DropdownMenuItem>Edit Player</DropdownMenuItem>
                                <DropdownMenuItem>Assign to Group</DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-8 text-gray-500">
                          {searchTerm ? "No players match your search" : "No players registered yet"}
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Player Registration Form Dialog */}
      <PlayerForm 
        isOpen={isPlayerFormOpen} 
        onClose={() => setIsPlayerFormOpen(false)} 
      />
    </Layout>
  );
}
