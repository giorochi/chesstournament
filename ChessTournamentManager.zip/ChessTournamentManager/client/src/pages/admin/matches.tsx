import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Layout from "@/components/layout/layout";
import MatchCard from "@/components/match-card";
import PairingGenerator from "@/components/pairing-generator";
import MatchResultForm from "@/components/match-result-form";

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { CalendarClock, CheckCircle, Clock, Filter } from "lucide-react";

export default function AdminMatches() {
  const [selectedGroup, setSelectedGroup] = useState<string>("all");
  const [selectedStatus, setSelectedStatus] = useState<string>("all");
  const [isPairingFormOpen, setIsPairingFormOpen] = useState(false);
  const [selectedMatch, setSelectedMatch] = useState<number | null>(null);
  
  // Get active tournament
  const { data: activeTournament, isLoading: tournamentLoading } = useQuery({
    queryKey: ["/api/tournaments/active"],
  });

  // Get tournament groups
  const { data: groups = [] } = useQuery({
    queryKey: [`/api/tournaments/${activeTournament?.id}/groups`],
    enabled: !!activeTournament?.id,
  });

  // Get matches
  const { data: matches = [], isLoading: matchesLoading } = useQuery({
    queryKey: [`/api/tournaments/${activeTournament?.id}/matches`],
    enabled: !!activeTournament?.id,
  });

  // Filter matches by group and status
  const filteredMatches = matches.filter((match: any) => {
    const groupMatches = selectedGroup === "all" || match.groupId?.toString() === selectedGroup;
    const statusMatches = selectedStatus === "all" ||
      (selectedStatus === "completed" && match.completed) ||
      (selectedStatus === "pending" && !match.completed);
    
    return groupMatches && statusMatches;
  });

  // Sort matches by date
  const sortedMatches = [...filteredMatches].sort((a: any, b: any) => {
    // Put matches with date first, then sort by date
    if (a.matchDate && !b.matchDate) return -1;
    if (!a.matchDate && b.matchDate) return 1;
    if (a.matchDate && b.matchDate) {
      return new Date(a.matchDate).getTime() - new Date(b.matchDate).getTime();
    }
    return 0;
  });

  // Group matches by stage/round
  const groupedMatches: Record<string, any[]> = {};
  
  sortedMatches.forEach((match: any) => {
    let group;
    
    if (match.isFinalStage) {
      group = match.finalStageRound 
        ? `Final Stage: ${match.finalStageRound.charAt(0).toUpperCase() + match.finalStageRound.slice(1)}`
        : "Final Stage";
    } else {
      const groupName = groups.find((g: any) => g.id === match.groupId)?.name || "Unknown Group";
      const roundText = match.roundNumber ? `Round ${match.roundNumber}` : "";
      group = `${groupName}${roundText ? ` - ${roundText}` : ""}`;
    }
    
    if (!groupedMatches[group]) {
      groupedMatches[group] = [];
    }
    
    groupedMatches[group].push(match);
  });

  // Get match by ID
  const getMatch = (id: number) => {
    return matches.find((match: any) => match.id === id);
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
          <div>
            <h1 className="text-2xl font-bold text-[#5D4037]">Matches Management</h1>
            <p className="text-gray-500">
              {matches.length || 0} matches in the {activeTournament?.name || 'tournament'}
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-2">
            <Button
              className="bg-[#1976D2] hover:bg-[#004BA0]"
              onClick={() => setIsPairingFormOpen(true)}
              disabled={!activeTournament}
            >
              <CalendarClock className="h-4 w-4 mr-2" />
              Create Pairings
            </Button>
          </div>
        </div>

        {!activeTournament ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500">No active tournament. Please activate a tournament first.</p>
            </CardContent>
          </Card>
        ) : (
          <>
            <Card>
              <CardHeader className="bg-[#5D4037] text-[#F5F5DC] pb-2">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-2 sm:space-y-0">
                  <CardTitle className="flex items-center">
                    <Filter className="h-5 w-5 mr-2" />
                    Filter Matches
                  </CardTitle>
                </div>
              </CardHeader>
              
              <CardContent className="p-4">
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="w-full sm:w-1/2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Group</label>
                    <Select value={selectedGroup} onValueChange={setSelectedGroup}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select a group" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Groups</SelectItem>
                        {groups.map((group: any) => (
                          <SelectItem key={group.id} value={group.id.toString()}>
                            {group.name}
                          </SelectItem>
                        ))}
                        <SelectItem value="final">Final Stages</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="w-full sm:w-1/2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                    <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Matches</SelectItem>
                        <SelectItem value="completed">Completed</SelectItem>
                        <SelectItem value="pending">Pending</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Tabs defaultValue="all" className="space-y-4">
              <TabsList>
                <TabsTrigger value="all">All Matches</TabsTrigger>
                <TabsTrigger value="pending">Pending</TabsTrigger>
                <TabsTrigger value="completed">Completed</TabsTrigger>
              </TabsList>
              
              {matchesLoading ? (
                <Card>
                  <CardContent className="p-8 text-center">
                    <p className="text-gray-500">Loading matches...</p>
                  </CardContent>
                </Card>
              ) : sortedMatches.length === 0 ? (
                <Card>
                  <CardContent className="p-8 text-center">
                    <p className="text-gray-500">No matches found for the selected filters.</p>
                  </CardContent>
                </Card>
              ) : (
                <>
                  <TabsContent value="all" className="space-y-6">
                    {Object.entries(groupedMatches).map(([group, matches]) => (
                      <div key={group} className="space-y-2">
                        <h2 className="text-lg font-semibold text-[#5D4037]">{group}</h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                          {matches.map((match: any) => (
                            <div key={match.id} className="relative">
                              <MatchCard match={match} />
                              {!match.completed && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="absolute top-2 right-2 bg-white"
                                  onClick={() => setSelectedMatch(match.id)}
                                >
                                  Enter Result
                                </Button>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </TabsContent>
                  
                  <TabsContent value="pending" className="space-y-6">
                    {Object.entries(groupedMatches).map(([group, allMatches]) => {
                      const pendingMatches = allMatches.filter((match: any) => !match.completed);
                      if (pendingMatches.length === 0) return null;
                      
                      return (
                        <div key={`pending-${group}`} className="space-y-2">
                          <div className="flex items-center">
                            <Clock className="h-5 w-5 mr-2 text-[#1976D2]" />
                            <h2 className="text-lg font-semibold text-[#5D4037]">{group}</h2>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {pendingMatches.map((match: any) => (
                              <div key={match.id} className="relative">
                                <MatchCard match={match} />
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="absolute top-2 right-2 bg-white"
                                  onClick={() => setSelectedMatch(match.id)}
                                >
                                  Enter Result
                                </Button>
                              </div>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </TabsContent>
                  
                  <TabsContent value="completed" className="space-y-6">
                    {Object.entries(groupedMatches).map(([group, allMatches]) => {
                      const completedMatches = allMatches.filter((match: any) => match.completed);
                      if (completedMatches.length === 0) return null;
                      
                      return (
                        <div key={`completed-${group}`} className="space-y-2">
                          <div className="flex items-center">
                            <CheckCircle className="h-5 w-5 mr-2 text-[#4CAF50]" />
                            <h2 className="text-lg font-semibold text-[#5D4037]">{group}</h2>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {completedMatches.map((match: any) => (
                              <MatchCard key={match.id} match={match} />
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </TabsContent>
                </>
              )}
            </Tabs>
          </>
        )}
      </div>

      {/* Pairing Generator Dialog */}
      <PairingGenerator 
        isOpen={isPairingFormOpen} 
        onClose={() => setIsPairingFormOpen(false)}
        tournamentId={activeTournament?.id}
      />

      {/* Match Result Form Dialog */}
      {selectedMatch && (
        <MatchResultForm 
          isOpen={!!selectedMatch}
          onClose={() => setSelectedMatch(null)}
          match={getMatch(selectedMatch)}
        />
      )}
    </Layout>
  );
}
